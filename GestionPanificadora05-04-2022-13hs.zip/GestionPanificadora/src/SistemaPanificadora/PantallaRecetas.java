package SistemaPanificadora;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.TableRowSorter;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Santi
 */
public class PantallaRecetas extends javax.swing.JFrame {

    /**
     * Creates new form PantallaRecetas
     */
    public static final String url = "jdbc:mysql://localhost/panificadora";
    public static final String username = "root";
    public static final String password = "";

    DefaultTableModel model;
    private Connection con = null;
    PreparedStatement ps;
    ResultSet rs;

    String Prod[] = new String[5];
    private Object nombre;

    public PantallaRecetas() {
        initComponents();
        cargar("");
         cargarprod();
     //  cargarDetalleReceta("");
        cargaMP();
       verreceta();
       cargarDetalleenReceta("");
        
  
        Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocationRelativeTo(null);
        NuevaReceta.setSize(590, 440);

     

    }
    Connection conn = null;

    void cargarprod() {
        try {

            conn = DriverManager.getConnection(url, username, password);
            String SQL = "SELECT * FROM producto where statusbajaprod is null";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()){
jComboBox2.addItem(rs.getString("descripcion"));
        

             
            }
            
        } catch (Exception e) {

        }
    }

    void cargar(String Valor) {
   
        Connection conn = null;
   
        String[] titulos = {"cod Receta", "ingrediente", "cantidad", "unidad medida"};
        model = new DefaultTableModel(null, titulos);
        String rcdt[] = new String[5];

        try {

            conn = DriverManager.getConnection(url, username, password);
            String SQL = "select * from receta where statusbajarc is null ";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                rcdt[0] = rs.getString("id_receta");
                rcdt[1] = rs.getString("nombre");
                rcdt[2] = rs.getString("cantidad");
                rcdt[3] = rs.getString("unidad_medida");
                //rcdt[4] = rs.getString("id_producto");
             nombrecdt.addItem(rs.getString("nombre"));

                model.addRow(rcdt);
               
             recetavalor.setModel(model);
             
             
             jComboBox7.addItem(rs.getString("unidad_medida"));
               
                    
               
                rectanomb.addItem(rs.getString("nombre"));
            }

        } catch (Exception e) {

        }

    }
    void verreceta(){
        Connection conn = null;
           String[] titulos = {"nombre","cantidad","unidad medida"};
        model = new DefaultTableModel(null, titulos);
        String rc[] = new String[3];
        try {

       conn = DriverManager.getConnection(url, username, password);
            String SQL = "SELECT id_receta,nombre,cantidad,unidad_medida FROM receta where statusbajarc is null";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
        
            while (rs.next()) {

                rc[0] = rs.getString("nombre");
                rc[1] = rs.getString("cantidad");
                rc[2] = rs.getString("unidad_medida");
                
                
                jComboBox1.addItem(rs.getString("nombre"));  
                unimedtxt.addItem(rs.getString("unidad_medida"));
                
                model.addRow(rc);
                  
                  tabledtr.setModel(model);
                  
                
    }
       
            } catch (Exception e) {

        }
    }
    



    void cargarDetalleReceta(String valordtr) {
  Connection conn = null;

        String[] titulos = {"cod detalle receta", "Ingrediente", "cantidad", "Unidad medida","receta"};
        model = new DefaultTableModel(null, titulos);
        String dtr[] = new String[5];

        try {

            conn = DriverManager.getConnection(url, username, password);
            String SQL = "select * from detalle_receta AS dtr JOIN materia_prima mp ON dtr.id_materia_prima = mp.id_materia_prima  where id_detalle_receta LIKE '%" + valordtr + "%' and statusbajadtrc is null";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                dtr[0] = rs.getString("id_detalle_receta");
                dtr[1] = rs.getString("descripcion");
                dtr[2] = rs.getString("cantidad");
                dtr[3] = rs.getString("unidad_medida");
                dtr[4] = rs.getString("id_receta");

                    model.addRow(dtr);
                 jTable4.setModel(model);
                 jTable1.setModel(model);
                 
               
                
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
    }
    void cargarDetalleenReceta(String valordtr) {
  Connection conn = null;

        String[] titulos = {"cod detalle receta", "Ingrediente", "cantidad", "Unidad medida","receta"};
        model = new DefaultTableModel(null, titulos);
        String dtr[] = new String[5];

        try {

            conn = DriverManager.getConnection(url, username, password);
            String SQL = "select * from detalle_receta AS dtr JOIN materia_prima mp ON dtr.id_materia_prima = mp.id_materia_prima  where id_detalle_receta LIKE '%" + valordtr + "%' and statusbajadtrc is null";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                dtr[0] = rs.getString("id_detalle_receta");
                dtr[1] = rs.getString("descripcion");
                dtr[2] = rs.getString("cantidad");
                dtr[3] = rs.getString("unidad_medida");
                dtr[4] = rs.getString("id_receta");

                    model.addRow(dtr);
                 jTable4.setModel(model);
             
                 
               
                
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
    }

    // carga de Materia Prima Para vincularlo al detalle de receta.
    void cargaMP() {
Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, username, password);
            String SQL = "select descripcion, statusbajamp from materia_prima  where statusbajamp is null";
           Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while(rs.next()){
       
                  jComboBox6.addItem(rs.getString("descripcion"));
            
            }

        } catch (Exception e) {

        }
    }

    public static Connection getConexion() {

        Connection con = null;

        try {

            Class.forName("com.mysql.jdbc.Driver");

            con = (Connection) DriverManager.getConnection(url, username, password);

        } catch (Exception e) {
            System.out.println(e);

        }

        return con;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        NuevaReceta = new javax.swing.JFrame();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        MPbotonMateriaPrima13 = new rsbuttom.RSButtonMetro();
        jPanel13 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        unimedtxt = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        producetxt = new javax.swing.JSpinner();
        jPanel19 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jSeparator15 = new javax.swing.JSeparator();
        jSeparator16 = new javax.swing.JSeparator();
        jSeparator17 = new javax.swing.JSeparator();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jSeparator18 = new javax.swing.JSeparator();
        nombrecdt = new javax.swing.JComboBox<>();
        jComboBox6 = new javax.swing.JComboBox<>();
        jComboBox7 = new javax.swing.JComboBox<>();
        rSButtonMetro4 = new rsbuttom.RSButtonMetro();
        jSpinner2 = new javax.swing.JSpinner();
        jLabel27 = new javax.swing.JLabel();
        añadirrecbtn = new rsbuttom.RSButtonMetro();
        jComboBox2 = new javax.swing.JComboBox<>();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jPanel18 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabledtr = new javax.swing.JTable();
        jPanel20 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        ModificarReceta = new javax.swing.JFrame();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jPanel14 = new javax.swing.JPanel();
        MPbotonMateriaPrima2 = new rsbuttom.RSButtonMetro();
        jSeparator1 = new javax.swing.JSeparator();
        MPbotonMateriaPrima12 = new rsbuttom.RSButtonMetro();
        jPanel15 = new javax.swing.JPanel();
        buscarbtn = new rsbuttom.RSButtonMetro();
        jLabel11 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jSeparator7 = new javax.swing.JSeparator();
        nombrerec = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jSeparator9 = new javax.swing.JSeparator();
        jSeparator10 = new javax.swing.JSeparator();
        unimedmodrec = new javax.swing.JComboBox<>();
        modifrecspinner = new javax.swing.JSpinner();
        rectanomb = new javax.swing.JComboBox<>();
        modifrecbtn1 = new rsbuttom.RSButtonMetro();
        Verprocedimientos = new javax.swing.JFrame();
        jPanel11 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        MPbotonMateriaPrima11 = new rsbuttom.RSButtonMetro();
        jSeparator8 = new javax.swing.JSeparator();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        modificarProcedimientos = new javax.swing.JFrame();
        jPanel10 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jEditorPane1 = new javax.swing.JEditorPane();
        MPbotonMateriaPrima5 = new rsbuttom.RSButtonMetro();
        MPbotonMateriaPrima6 = new rsbuttom.RSButtonMetro();
        jLabel7 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        recetavalor = new javax.swing.JTable();
        jPanel9 = new javax.swing.JPanel();
        aux = new javax.swing.JTextField();
        ModificarBoton = new rsbuttom.RSButtonMetro();
        jLabel8 = new javax.swing.JLabel();
        ModificarBoton1 = new rsbuttom.RSButtonMetro();
        NuevaRecetaBoton1 = new rsbuttom.RSButtonMetro();
        ModificarBoton2 = new rsbuttom.RSButtonMetro();
        jLabel2 = new javax.swing.JLabel();
        Eliminarrc = new rsbuttom.RSButtonMetro();

        jPanel3.setBackground(new java.awt.Color(244, 243, 239));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(230, 205, 141));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton2.setBackground(new java.awt.Color(230, 205, 141));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 12, 66, 53));

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel19.setText("Añadir Receta");
        jPanel4.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, -1, 42));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("Añadir detalle de receta");
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, -1, 42));

        jPanel3.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 420, 70));

        jPanel16.setBackground(new java.awt.Color(244, 243, 239));
        jPanel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel16.setLayout(null);

        MPbotonMateriaPrima13.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima13.setText("Volver al Home");
        MPbotonMateriaPrima13.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima13.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima13.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima13.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima13.setDefaultCapable(false);
        MPbotonMateriaPrima13.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        MPbotonMateriaPrima13.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima13.setIconTextGap(25);
        MPbotonMateriaPrima13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima13ActionPerformed(evt);
            }
        });
        jPanel16.add(MPbotonMateriaPrima13);
        MPbotonMateriaPrima13.setBounds(330, 460, 199, 50);

        jPanel13.setBackground(new java.awt.Color(244, 243, 239));
        jPanel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel4.setText("Nombre:");
        jPanel13.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, 30));

        jLabel5.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel5.setText("¿Cuanto rinde?:");
        jPanel13.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, 30));
        jPanel13.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 310, 10));
        jPanel13.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 310, 10));
        jPanel13.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 310, 10));

        unimedtxt.setEditable(true);
        unimedtxt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        unimedtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unimedtxtActionPerformed(evt);
            }
        });
        jPanel13.add(unimedtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 110, 140, 30));

        jLabel12.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel12.setText("Ingrese unidad medida:");
        jPanel13.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, 30));
        jPanel13.add(producetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 70, 140, -1));

        jPanel19.setBackground(new java.awt.Color(244, 243, 239));
        jPanel19.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel19.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel22.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel22.setText("Materia_prima");
        jPanel19.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, 40));
        jPanel19.add(jSeparator15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 310, 10));
        jPanel19.add(jSeparator16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 310, 10));
        jPanel19.add(jSeparator17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 310, 10));

        jLabel25.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel25.setText("Ingrese unidad medida:");
        jPanel19.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, 40));

        jLabel26.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel26.setText("Cantidad");
        jPanel19.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, 30));
        jPanel19.add(jSeparator18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 310, 10));

        nombrecdt.setEditable(true);
        nombrecdt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        nombrecdt.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                nombrecdtItemStateChanged(evt);
            }
        });
        jPanel19.add(nombrecdt, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 20, 120, -1));

        jComboBox6.setEditable(true);
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jPanel19.add(jComboBox6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 70, 120, -1));

        jComboBox7.setEditable(true);
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jPanel19.add(jComboBox7, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 120, 120, -1));

        rSButtonMetro4.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro4.setForeground(new java.awt.Color(0, 0, 0));
        rSButtonMetro4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/añadir.png"))); // NOI18N
        rSButtonMetro4.setText("Agregar");
        rSButtonMetro4.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro4.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro4.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro4.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro4.setColorTextPressed(new java.awt.Color(0, 0, 0));
        rSButtonMetro4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        rSButtonMetro4.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        rSButtonMetro4.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        rSButtonMetro4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro4ActionPerformed(evt);
            }
        });
        jPanel19.add(rSButtonMetro4, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 60, 100, 70));
        jPanel19.add(jSpinner2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 160, 116, -1));

        jLabel27.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel27.setText("Receta");
        jPanel19.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, 40));

        jPanel13.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 0, 470, 290));

        añadirrecbtn.setBackground(new java.awt.Color(244, 243, 239));
        añadirrecbtn.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        añadirrecbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Confirmar.png"))); // NOI18N
        añadirrecbtn.setText("Añadir");
        añadirrecbtn.setColorBorde(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        añadirrecbtn.setColorHover(new java.awt.Color(230, 205, 141));
        añadirrecbtn.setColorNormal(new java.awt.Color(244, 243, 239));
        añadirrecbtn.setColorPressed(new java.awt.Color(244, 237, 210));
        añadirrecbtn.setColorTextNormal(new java.awt.Color(0, 0, 0));
        añadirrecbtn.setDefaultCapable(false);
        añadirrecbtn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        añadirrecbtn.setIconTextGap(25);
        añadirrecbtn.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        añadirrecbtn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        añadirrecbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                añadirrecbtnActionPerformed(evt);
            }
        });
        jPanel13.add(añadirrecbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 40, 70, 100));

        jComboBox2.setEditable(true);
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar o Escribir" }));
        jPanel13.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 20, 140, 20));

        jPanel16.add(jPanel13);
        jPanel13.setBounds(0, 150, 890, 290);

        jTable4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane5.setViewportView(jTable4);

        jPanel16.add(jScrollPane5);
        jScrollPane5.setBounds(420, 0, 470, 150);

        jPanel18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        tabledtr.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(tabledtr);

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 418, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 148, Short.MAX_VALUE)
        );

        jPanel16.add(jPanel18);
        jPanel18.setBounds(0, 0, 420, 150);

        jPanel20.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 468, Short.MAX_VALUE)
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 148, Short.MAX_VALUE)
        );

        jPanel16.add(jPanel20);
        jPanel20.setBounds(420, 0, 470, 150);

        jPanel3.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 890, 530));

        jPanel17.setBackground(new java.awt.Color(230, 205, 141));
        jPanel17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel13.setText("Añadir detalle de receta");
        jPanel17.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, -1, 42));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("Añadir detalle de receta");
        jPanel17.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, 230, 50));

        jPanel3.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 0, 470, 70));

        NuevaReceta.getContentPane().add(jPanel3, java.awt.BorderLayout.CENTER);

        jPanel7.setBackground(new java.awt.Color(244, 243, 239));
        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel8.setBackground(new java.awt.Color(230, 205, 141));
        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setText("Modificar Receta");
        jPanel8.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 30, -1, 42));

        jButton4.setBackground(new java.awt.Color(230, 205, 141));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel8.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 12, -1, -1));

        jPanel7.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 700, 80));

        jPanel14.setBackground(new java.awt.Color(244, 243, 239));
        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jPanel14.setLayout(null);

        MPbotonMateriaPrima2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Boton-buscar.png"))); // NOI18N
        MPbotonMateriaPrima2.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima2.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima2.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima2.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima2.setDefaultCapable(false);
        MPbotonMateriaPrima2.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima2.setIconTextGap(25);
        MPbotonMateriaPrima2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima2ActionPerformed(evt);
            }
        });
        jPanel14.add(MPbotonMateriaPrima2);
        MPbotonMateriaPrima2.setBounds(520, 180, 36, 35);
        jPanel14.add(jSeparator1);
        jSeparator1.setBounds(210, 230, 312, 2);

        jPanel7.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 140, -1, -1));

        MPbotonMateriaPrima12.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima12.setText("Volver al Home");
        MPbotonMateriaPrima12.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima12.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima12.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima12.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima12.setDefaultCapable(false);
        MPbotonMateriaPrima12.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        MPbotonMateriaPrima12.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima12.setIconTextGap(25);
        MPbotonMateriaPrima12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima12ActionPerformed(evt);
            }
        });
        jPanel7.add(MPbotonMateriaPrima12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, 199, 50));

        jPanel15.setBackground(new java.awt.Color(244, 243, 239));
        jPanel15.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Ingrese la Receta", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto Thin", 1, 14))); // NOI18N
        jPanel15.setLayout(null);

        buscarbtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Boton-buscar.png"))); // NOI18N
        buscarbtn.setColorHover(new java.awt.Color(230, 205, 141));
        buscarbtn.setColorNormal(new java.awt.Color(244, 243, 239));
        buscarbtn.setColorPressed(new java.awt.Color(244, 237, 210));
        buscarbtn.setColorTextNormal(new java.awt.Color(0, 0, 0));
        buscarbtn.setColorTextPressed(new java.awt.Color(0, 0, 0));
        buscarbtn.setDefaultCapable(false);
        buscarbtn.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        buscarbtn.setIconTextGap(25);
        buscarbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarbtnActionPerformed(evt);
            }
        });
        jPanel15.add(buscarbtn);
        buscarbtn.setBounds(410, 30, 50, 35);

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel11.setText("Receta");
        jPanel15.add(jLabel11);
        jLabel11.setBounds(10, 30, 220, 30);

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel15.setText("Nombre Receta:");
        jPanel15.add(jLabel15);
        jLabel15.setBounds(10, 80, 140, 30);
        jPanel15.add(jSeparator7);
        jSeparator7.setBounds(10, 170, 390, 10);
        jPanel15.add(nombrerec);
        nombrerec.setBounds(240, 80, 160, 30);

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel16.setText("Cantidad que produce:");
        jPanel15.add(jLabel16);
        jLabel16.setBounds(10, 130, 180, 30);

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel17.setText("Unidad de Medida:");
        jPanel15.add(jLabel17);
        jLabel17.setBounds(10, 180, 127, 30);
        jPanel15.add(jSeparator9);
        jSeparator9.setBounds(10, 70, 390, 10);
        jPanel15.add(jSeparator10);
        jSeparator10.setBounds(10, 120, 390, 10);

        unimedmodrec.setEditable(true);
        unimedmodrec.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jPanel15.add(unimedmodrec);
        unimedmodrec.setBounds(240, 180, 160, 30);
        jPanel15.add(modifrecspinner);
        modifrecspinner.setBounds(240, 130, 160, 30);

        rectanomb.setEditable(true);
        rectanomb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        rectanomb.setToolTipText("");
        jPanel15.add(rectanomb);
        rectanomb.setBounds(240, 30, 160, 30);

        jPanel7.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 100, 490, 230));

        modifrecbtn1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        modifrecbtn1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar_1.png"))); // NOI18N
        modifrecbtn1.setText("Modificar");
        modifrecbtn1.setColorHover(new java.awt.Color(230, 205, 141));
        modifrecbtn1.setColorNormal(new java.awt.Color(244, 243, 239));
        modifrecbtn1.setColorPressed(new java.awt.Color(244, 237, 210));
        modifrecbtn1.setColorTextNormal(new java.awt.Color(0, 0, 0));
        modifrecbtn1.setDefaultCapable(false);
        modifrecbtn1.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        modifrecbtn1.setIconTextGap(25);
        modifrecbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifrecbtn1ActionPerformed(evt);
            }
        });
        jPanel7.add(modifrecbtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 420, 174, 55));

        javax.swing.GroupLayout ModificarRecetaLayout = new javax.swing.GroupLayout(ModificarReceta.getContentPane());
        ModificarReceta.getContentPane().setLayout(ModificarRecetaLayout);
        ModificarRecetaLayout.setHorizontalGroup(
            ModificarRecetaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        ModificarRecetaLayout.setVerticalGroup(
            ModificarRecetaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
        );

        Verprocedimientos.getContentPane().setLayout(null);

        jPanel11.setBackground(new java.awt.Color(230, 205, 141));
        jPanel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel11.setLayout(null);

        jLabel20.setFont(new java.awt.Font("Roboto Thin", 1, 18)); // NOI18N
        jLabel20.setText("Visualizar Detalles de Recetas");
        jPanel11.add(jLabel20);
        jLabel20.setBounds(230, 20, 260, 30);

        jButton5.setBackground(new java.awt.Color(230, 205, 141));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton5);
        jButton5.setBounds(11, 12, 66, 57);

        Verprocedimientos.getContentPane().add(jPanel11);
        jPanel11.setBounds(1, 1, 700, 80);

        jPanel6.setBackground(new java.awt.Color(244, 243, 239));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        MPbotonMateriaPrima11.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima11.setText("Volver al Home");
        MPbotonMateriaPrima11.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima11.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima11.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima11.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima11.setDefaultCapable(false);
        MPbotonMateriaPrima11.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        MPbotonMateriaPrima11.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima11.setIconTextGap(25);
        MPbotonMateriaPrima11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima11ActionPerformed(evt);
            }
        });
        jPanel6.add(MPbotonMateriaPrima11, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 320, 200, 50));
        jPanel6.add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 200, 10));

        jComboBox1.setEditable(true);
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Buscar" }));
        jComboBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox1ItemStateChanged(evt);
            }
        });
        jComboBox1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComboBox1MouseClicked(evt);
            }
        });
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        jComboBox1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jComboBox1KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jComboBox1KeyReleased(evt);
            }
        });
        jPanel6.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 10, 113, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel14.setText("Nombre de la Receta:");
        jPanel6.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane4.setViewportView(jTable1);

        jPanel6.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 680, 260));

        Verprocedimientos.getContentPane().add(jPanel6);
        jPanel6.setBounds(0, 80, 700, 380);

        jPanel10.setBackground(new java.awt.Color(244, 243, 239));
        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPanel12.setBackground(new java.awt.Color(230, 205, 141));
        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButton6.setBackground(new java.awt.Color(230, 205, 141));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Roboto Thin", 1, 18)); // NOI18N
        jLabel21.setText("Modificar Procedimientos");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(165, 165, 165)
                .addComponent(jLabel21)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 56, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );

        jScrollPane2.setViewportView(jEditorPane1);

        MPbotonMateriaPrima5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar_1.png"))); // NOI18N
        MPbotonMateriaPrima5.setText("Modificar");
        MPbotonMateriaPrima5.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima5.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima5.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima5.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima5.setDefaultCapable(false);
        MPbotonMateriaPrima5.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima5.setIconTextGap(25);
        MPbotonMateriaPrima5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima5ActionPerformed(evt);
            }
        });

        MPbotonMateriaPrima6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MPbotonMateriaPrima6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima6.setText("Volver al Home");
        MPbotonMateriaPrima6.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima6.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima6.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima6.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima6.setDefaultCapable(false);
        MPbotonMateriaPrima6.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        MPbotonMateriaPrima6.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima6.setIconTextGap(25);
        MPbotonMateriaPrima6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima6ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel7.setText("Haga click en el campo para Editar la Receta:");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(MPbotonMateriaPrima6, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 305, Short.MAX_VALUE)
                        .addComponent(MPbotonMateriaPrima5, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43))))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jLabel7)
                        .addGap(270, 270, 270))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MPbotonMateriaPrima5, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(MPbotonMateriaPrima6, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        modificarProcedimientos.getContentPane().add(jPanel10, java.awt.BorderLayout.CENTER);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(244, 243, 239));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(230, 205, 141));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Roboto Thin", 1, 36)); // NOI18N
        jLabel1.setText("Recetas");

        jButton1.setBackground(new java.awt.Color(230, 205, 141));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(253, 253, 253)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(367, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 70));

        recetavalor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(recetavalor);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 770, 200));

        jPanel9.setBackground(new java.awt.Color(244, 243, 239));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel9.setLayout(null);

        aux.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                auxActionPerformed(evt);
            }
        });
        aux.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                auxKeyReleased(evt);
            }
        });
        jPanel9.add(aux);
        aux.setBounds(245, 158, 130, 30);

        ModificarBoton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        ModificarBoton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Boton-buscar.png"))); // NOI18N
        ModificarBoton.setColorBorde(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        ModificarBoton.setColorHover(new java.awt.Color(230, 205, 141));
        ModificarBoton.setColorNormal(new java.awt.Color(244, 243, 239));
        ModificarBoton.setColorPressed(new java.awt.Color(244, 237, 210));
        ModificarBoton.setColorTextHover(new java.awt.Color(0, 0, 0));
        ModificarBoton.setColorTextNormal(new java.awt.Color(0, 0, 0));
        ModificarBoton.setColorTextPressed(new java.awt.Color(0, 0, 0));
        ModificarBoton.setDefaultCapable(false);
        ModificarBoton.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        ModificarBoton.setIconTextGap(25);
        ModificarBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModificarBotonActionPerformed(evt);
            }
        });
        jPanel9.add(ModificarBoton);
        ModificarBoton.setBounds(381, 146, 50, 40);

        jLabel8.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel8.setText("Ingrese el nombre de una receta:");
        jPanel9.add(jLabel8);
        jLabel8.setBounds(11, 156, 209, 30);

        ModificarBoton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        ModificarBoton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons2/ver.png"))); // NOI18N
        ModificarBoton1.setText("Visualizar detalle receta");
        ModificarBoton1.setColorBorde(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        ModificarBoton1.setColorHover(new java.awt.Color(230, 205, 141));
        ModificarBoton1.setColorNormal(new java.awt.Color(244, 243, 239));
        ModificarBoton1.setColorPressed(new java.awt.Color(244, 237, 210));
        ModificarBoton1.setColorTextHover(new java.awt.Color(0, 0, 0));
        ModificarBoton1.setColorTextNormal(new java.awt.Color(0, 0, 0));
        ModificarBoton1.setColorTextPressed(new java.awt.Color(0, 0, 0));
        ModificarBoton1.setDefaultCapable(false);
        ModificarBoton1.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        ModificarBoton1.setIconTextGap(10);
        ModificarBoton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModificarBoton1ActionPerformed(evt);
            }
        });
        jPanel9.add(ModificarBoton1);
        ModificarBoton1.setBounds(271, 55, 241, 50);

        NuevaRecetaBoton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        NuevaRecetaBoton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/añadirReceta.png"))); // NOI18N
        NuevaRecetaBoton1.setText("Añadir Nueva Receta");
        NuevaRecetaBoton1.setColorBorde(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        NuevaRecetaBoton1.setColorHover(new java.awt.Color(230, 205, 141));
        NuevaRecetaBoton1.setColorNormal(new java.awt.Color(244, 243, 239));
        NuevaRecetaBoton1.setColorPressed(new java.awt.Color(244, 237, 210));
        NuevaRecetaBoton1.setColorTextHover(new java.awt.Color(0, 0, 0));
        NuevaRecetaBoton1.setColorTextNormal(new java.awt.Color(0, 0, 0));
        NuevaRecetaBoton1.setColorTextPressed(new java.awt.Color(0, 0, 0));
        NuevaRecetaBoton1.setDefaultCapable(false);
        NuevaRecetaBoton1.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        NuevaRecetaBoton1.setIconTextGap(25);
        NuevaRecetaBoton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NuevaRecetaBoton1ActionPerformed(evt);
            }
        });
        jPanel9.add(NuevaRecetaBoton1);
        NuevaRecetaBoton1.setBounds(33, 55, 220, 50);

        ModificarBoton2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        ModificarBoton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Editar.png"))); // NOI18N
        ModificarBoton2.setText("Modificar receta");
        ModificarBoton2.setColorBorde(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        ModificarBoton2.setColorHover(new java.awt.Color(230, 205, 141));
        ModificarBoton2.setColorNormal(new java.awt.Color(244, 243, 239));
        ModificarBoton2.setColorPressed(new java.awt.Color(244, 237, 210));
        ModificarBoton2.setColorTextHover(new java.awt.Color(0, 0, 0));
        ModificarBoton2.setColorTextNormal(new java.awt.Color(0, 0, 0));
        ModificarBoton2.setColorTextPressed(new java.awt.Color(0, 0, 0));
        ModificarBoton2.setDefaultCapable(false);
        ModificarBoton2.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        ModificarBoton2.setIconTextGap(25);
        ModificarBoton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModificarBoton2ActionPerformed(evt);
            }
        });
        jPanel9.add(ModificarBoton2);
        ModificarBoton2.setBounds(540, 55, 249, 50);

        jLabel2.setFont(new java.awt.Font("Roboto Thin", 1, 18)); // NOI18N
        jLabel2.setText("¿Que desea hacer?");
        jPanel9.add(jLabel2);
        jLabel2.setBounds(0, 0, 180, 22);

        jPanel1.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 850, 200));

        Eliminarrc.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Eliminarrc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/eliminar.png"))); // NOI18N
        Eliminarrc.setColorHover(new java.awt.Color(230, 205, 141));
        Eliminarrc.setColorNormal(new java.awt.Color(244, 243, 239));
        Eliminarrc.setColorPressed(new java.awt.Color(244, 237, 210));
        Eliminarrc.setColorTextNormal(new java.awt.Color(0, 0, 0));
        Eliminarrc.setDefaultCapable(false);
        Eliminarrc.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        Eliminarrc.setIconTextGap(25);
        Eliminarrc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarrcActionPerformed(evt);
            }
        });
        jPanel1.add(Eliminarrc, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 350, 50, 50));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);
        this.setVisible(false);

    }//GEN-LAST:event_jButton1ActionPerformed

    private void ModificarBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModificarBotonActionPerformed
 // TODO add your handling code here:
      
     
                                              
        

    }//GEN-LAST:event_ModificarBotonActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        NuevaReceta.setVisible(false);
        PantallaRecetas recetashome = new PantallaRecetas();
        recetashome.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void EliminarrcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarrcActionPerformed

        Date fecha=new Date();
       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
     String fechaactual=sdf.format(fecha);
     
        int fila = recetavalor.getSelectedRow();

        int valor = parseInt(recetavalor.getValueAt(fila, 0).toString());

if (fila >= 0) {
            try {
                con = getConexion();
                ps = con.prepareStatement("UPDATE receta SET statusbajarc=? WHERE id_receta=" + valor);
ps.setString(1, fechaactual);
  int res = ps.executeUpdate();
  cargar("");
if (res > 0) {
                JOptionPane.showMessageDialog(null, "La receta fue dado de baja");
               
            }   

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "La receta no se ha podido dar de baja");
            }
          
        
        }
       try {
                con = getConexion();
                ps = con.prepareStatement("UPDATE detalle_receta SET statusbajadtrc=? WHERE id_receta=" + valor);
ps.setString(1, fechaactual);
  int res = ps.executeUpdate();
if (res > 0) {
                JOptionPane.showMessageDialog(null, "El detalle de receta fue dado de baja");
                cargar("");
            }    
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "El detalle de receta no se ha podido dar de baja");
            }
        
        
    }//GEN-LAST:event_EliminarrcActionPerformed

    private void MPbotonMateriaPrima2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MPbotonMateriaPrima2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        ModificarReceta.setVisible(false);
        PantallaRecetas recetahome = new PantallaRecetas();
        recetahome.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void auxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_auxActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_auxActionPerformed

    private void ModificarBoton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModificarBoton1ActionPerformed
        Verprocedimientos.setSize(715, 505);
        Verprocedimientos.setLocationRelativeTo(null);

        Verprocedimientos.setVisible(true);
        this.setVisible(false);
        dispose();// TODO add your handling code here:
    }//GEN-LAST:event_ModificarBoton1ActionPerformed

    private void añadirrecbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_añadirrecbtnActionPerformed

        // orden de produccion insertar dato
      
        try {
String datotexto1 =(String) jComboBox2.getSelectedItem();
//int id = (int) jComboBox2.getSelectedIndex();
            int produce = (int) producetxt.getValue();
         
          //  int datotexto2 = (int) jComboBox2.getSelectedIndex();
            String unidadmedida = (String) unimedtxt.getSelectedItem();
       
            //Inserto datos del valor de la receta
            con = getConexion();
            ps = con.prepareStatement("INSERT INTO receta(nombre,cantidad,unidad_medida) VALUES (?,?,?)");

            ps.setString(1, datotexto1);
            ps.setInt(2, produce);
            ps.setString(3, unidadmedida);
        
           

            int res = ps.executeUpdate();
           cargar("");   
         if (res > 0) {
                JOptionPane.showMessageDialog(null, "LA RECETA HA SIDO AGREGADA CORRECTAMENTE");

            } else {
                JOptionPane.showMessageDialog(null, "LA RECETA NO SE HA AGREGADO CORRECTAMENTE");

            }
            
            con.close();
        } catch (Exception e) {
            System.err.println(e);

        }

        int idrecmax = 1;
      

       


    }//GEN-LAST:event_añadirrecbtnActionPerformed

    private void NuevaRecetaBoton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NuevaRecetaBoton1ActionPerformed
        dispose();

        NuevaReceta.setSize(925, 555);
        NuevaReceta.setVisible(true);
        NuevaReceta.setResizable(false);
        NuevaReceta.setLocationRelativeTo(null);

    }//GEN-LAST:event_NuevaRecetaBoton1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        Verprocedimientos.setVisible(false);
        PantallaRecetas home = new PantallaRecetas();
        home.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void ModificarBoton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModificarBoton2ActionPerformed
        dispose();
        ModificarReceta.setVisible(true);
        ModificarReceta.setSize(700, 520);
        ModificarReceta.setLocationRelativeTo(null);
    }//GEN-LAST:event_ModificarBoton2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        modificarProcedimientos.setVisible(false);
        Verprocedimientos.setVisible(true);
        Verprocedimientos.setSize(1100, 1100);
        Verprocedimientos.setResizable(false);
        Verprocedimientos.setLocationRelativeTo(null);


    }//GEN-LAST:event_jButton6ActionPerformed

    private void MPbotonMateriaPrima5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima5ActionPerformed
        // TODO add your handling code here:Connection con = null;

        try {
            con = getConexion();
            ps = con.prepareStatement("INSERT INTO receta(procedimiento) VALUES (?)");

            ps.setString(1, jEditorPane1.getText());

            int res = ps.executeUpdate();

            if (res > 0) {
                cargar("");
                JOptionPane.showMessageDialog(null, "DATOS DEL PROCEDIMIENTO SE AGREGO CORRECTAMENTE");

            } else {
                JOptionPane.showMessageDialog(null, "EL PROCEDIMIENTO NO SE HA ELIMINADO CORRECTAMENTE");

            }

            con.close();

        } catch (Exception e) {
            System.err.println(e);

        }
    }//GEN-LAST:event_MPbotonMateriaPrima5ActionPerformed

    private void MPbotonMateriaPrima6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima6ActionPerformed
        Verprocedimientos.setVisible(false);
        modificarProcedimientos.setVisible(false);
        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);

        cargar("");
    }//GEN-LAST:event_MPbotonMateriaPrima6ActionPerformed

    private void MPbotonMateriaPrima11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima11ActionPerformed
        Verprocedimientos.setVisible(false);
        PantallaRecetas rc = new PantallaRecetas();
        rc.setVisible(false);
        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);

        cargar("");
    }//GEN-LAST:event_MPbotonMateriaPrima11ActionPerformed

    private void MPbotonMateriaPrima12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima12ActionPerformed
        ModificarReceta.setVisible(false);
        PantallaRecetas rc = new PantallaRecetas();
        rc.setVisible(false);
        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);

        cargar("");
    }//GEN-LAST:event_MPbotonMateriaPrima12ActionPerformed

    private void MPbotonMateriaPrima13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima13ActionPerformed
        NuevaReceta.setVisible(false);
        PantallaRecetas rc = new PantallaRecetas();
        rc.setVisible(false);
        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);

        cargar("");
    }//GEN-LAST:event_MPbotonMateriaPrima13ActionPerformed

    private void buscarbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarbtnActionPerformed

        Connection con = null;
        int nombrereceta = rectanomb.getSelectedIndex();
        nombrereceta = nombrereceta;

        try {
            con = getConexion();
            ps = con.prepareStatement("SELECT * FROM receta WHERE id_receta= ?");
            ps.setInt(1, nombrereceta);

            rs = ps.executeQuery();

            if (rs.next()) {
                nombrerec.setText(rs.getString("nombre"));
                modifrecspinner.setValue(rs.getInt("cantidad"));
                unimedmodrec.setSelectedItem(rs.getString("unidad_medida"));
            } else {
                JOptionPane.showMessageDialog(null, "No existe una receta con ese nombre");
            }

        } catch (Exception e) {
            System.err.println(e);
        }
    }//GEN-LAST:event_buscarbtnActionPerformed

    private void unimedtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unimedtxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_unimedtxtActionPerformed

    private void modifrecbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifrecbtn1ActionPerformed
     Connection con = null;
        String unidadmedida=(String)unimedmodrec.getSelectedItem();
       
        String recetanom =(String) rectanomb.getSelectedItem();
        
        try{
            
            con = getConexion();
            
            int contadorreceta = (int) modifrecspinner.getValue();
            
            ps = con.prepareStatement("UPDATE receta SET nombre=?,cantidad=?,unidad_medida=? WHERE nombre=?");

            
            ps.setString(1, nombrerec.getText());
            ps.setInt(2, contadorreceta);
            ps.setString(3, unidadmedida);
            ps.setString(4, recetanom);
            
            


            int res = ps.executeUpdate();
  cargar("");
            if(res > 0){
                JOptionPane.showMessageDialog(null, "LOS DATOS HAN SIDO MODIFICADOS CORRECTAMENTE");
               
               
            } else {
                JOptionPane.showMessageDialog(null, "LA RECETA NO SE HA MODIFICADO CORRECTAMENTE");
                
            }
          
            con.close();
            
        }catch(Exception e){
            System.err.println(e);

        }
    }//GEN-LAST:event_modifrecbtn1ActionPerformed

    private void rSButtonMetro4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro4ActionPerformed
        // TODO add your handling code here:
         Connection con = null;
        String unidadmedida = (String)jComboBox7.getSelectedItem();

        int cantidad = (int) jSpinner2.getValue();
        int selectrec = (int) nombrecdt.getSelectedIndex();
        int selectmp = (int) jComboBox6.getSelectedIndex();

        try {
            con = getConexion();

            ps = con.prepareStatement("INSERT INTO detalle_receta(cantidad,unidad_medida,id_receta,id_materia_prima) VALUES (?,?,?,?)");

            ps.setInt(1, cantidad);
            ps.setString(2, unidadmedida);
            ps.setInt(3, selectrec);
            ps.setInt(4, selectmp);

            int res = ps.executeUpdate();
if (res > 0) {
                JOptionPane.showMessageDialog(null, "EL DETALLE DE RECETA SE GENERO CORRECTAMENTE");
                cargar("");
            } else {
                JOptionPane.showMessageDialog(null, "EL DETALLE DE RECETA NO SE HA GENERADO CORRECTAMENTE");
            }
        } catch (Exception e) {
            System.err.println(e);

        }


    }//GEN-LAST:event_rSButtonMetro4ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
         
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void auxKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_auxKeyReleased
        // TODO add your handling code here:
        cargar(aux.getText());
    }//GEN-LAST:event_auxKeyReleased

    private void jComboBox1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jComboBox1KeyReleased
        // TODO add your handling code here:
         
    
    }//GEN-LAST:event_jComboBox1KeyReleased

    private void jComboBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox1ItemStateChanged
int filtro=(int)jComboBox1.getSelectedIndex();
        Connection conn = null;

        String[] titulos = {"cod detalle receta", "Ingrediente", "cantidad", "Unidad medida","receta"};
        model = new DefaultTableModel(null, titulos);
        String filtrar[] = new String[5];

        try {
con = getConexion();
            conn = DriverManager.getConnection(url, username, password);
            String SQL = "select * from detalle_receta AS dtr JOIN materia_prima mp ON dtr.id_materia_prima = mp.id_materia_prima  where id_receta ="+ filtro;
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                filtrar[0] = rs.getString("id_detalle_receta");
                filtrar[1] = rs.getString("descripcion");
                filtrar[2] = rs.getString("cantidad");
                filtrar[3] = rs.getString("unidad_medida");
                filtrar[4] = rs.getString("id_receta");

                    model.addRow(filtrar);
                 jTable1.setModel(model);
                
                 
               
                
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
 
    }//GEN-LAST:event_jComboBox1ItemStateChanged

    private void jComboBox1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox1MouseClicked
        // TODO add your handling code here:`
        
    }//GEN-LAST:event_jComboBox1MouseClicked

    private void jComboBox1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jComboBox1KeyPressed
        // TODO add your handling code here:
         
    }//GEN-LAST:event_jComboBox1KeyPressed

    private void nombrecdtItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_nombrecdtItemStateChanged
        // TODO add your handling code here:
        int filtro=(int)nombrecdt.getSelectedIndex();
        Connection conn = null;

        String[] titulos = {"cod detalle receta", "Ingrediente", "cantidad", "Unidad medida","receta"};
        model = new DefaultTableModel(null, titulos);
        String filtrar[] = new String[5];

        try {
con = getConexion();
            conn = DriverManager.getConnection(url, username, password);
            String SQL = "select * from detalle_receta AS dtr JOIN materia_prima mp ON dtr.id_materia_prima = mp.id_materia_prima  where id_receta ="+ filtro;
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                filtrar[0] = rs.getString("id_detalle_receta");
                filtrar[1] = rs.getString("descripcion");
                filtrar[2] = rs.getString("cantidad");
                filtrar[3] = rs.getString("unidad_medida");
                filtrar[4] = rs.getString("id_receta");

                    model.addRow(filtrar);
                 jTable4.setModel(model);
                
                 
               
                
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
    }//GEN-LAST:event_nombrecdtItemStateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaRecetas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaRecetas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaRecetas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaRecetas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PantallaRecetas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private rsbuttom.RSButtonMetro Eliminarrc;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima11;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima12;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima13;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima2;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima5;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima6;
    private rsbuttom.RSButtonMetro ModificarBoton;
    private rsbuttom.RSButtonMetro ModificarBoton1;
    private rsbuttom.RSButtonMetro ModificarBoton2;
    private javax.swing.JFrame ModificarReceta;
    private javax.swing.JFrame NuevaReceta;
    private rsbuttom.RSButtonMetro NuevaRecetaBoton1;
    private javax.swing.JFrame Verprocedimientos;
    private javax.swing.JTextField aux;
    private rsbuttom.RSButtonMetro añadirrecbtn;
    private rsbuttom.RSButtonMetro buscarbtn;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JEditorPane jEditorPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator15;
    private javax.swing.JSeparator jSeparator16;
    private javax.swing.JSeparator jSeparator17;
    private javax.swing.JSeparator jSeparator18;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JSpinner jSpinner2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable4;
    private javax.swing.JFrame modificarProcedimientos;
    private rsbuttom.RSButtonMetro modifrecbtn1;
    private javax.swing.JSpinner modifrecspinner;
    private javax.swing.JComboBox<String> nombrecdt;
    private javax.swing.JTextField nombrerec;
    private javax.swing.JSpinner producetxt;
    private rsbuttom.RSButtonMetro rSButtonMetro4;
    private javax.swing.JTable recetavalor;
    private javax.swing.JComboBox<String> rectanomb;
    private javax.swing.JTable tabledtr;
    private javax.swing.JComboBox<String> unimedmodrec;
    private javax.swing.JComboBox<String> unimedtxt;
    // End of variables declaration//GEN-END:variables

}
