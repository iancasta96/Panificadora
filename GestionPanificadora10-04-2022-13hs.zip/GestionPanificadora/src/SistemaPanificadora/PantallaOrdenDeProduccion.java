/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SistemaPanificadora;

import java.awt.Dimension;
import java.awt.Toolkit;
import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

/**
 *
 * @author Ian
 */
public class PantallaOrdenDeProduccion extends javax.swing.JFrame {

    /**
     * Creates new form PantallaOrdenDeProduccion
     */
    public PantallaOrdenDeProduccion() {
        initComponents();
        AutoCompleteDecorator.decorate(this.jComboBox1);

        cargarrec();
        this.setLocationRelativeTo(null);
        cargarprod();
        cargardetalle();
        cargaropsindpp("");
        cargar("");
    }

    void cargarrec() {
        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        try {

            String SQL = "SELECT * FROM receta";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void cargarprod() {
        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        try {

            String SQL = "SELECT * FROM producto";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                jComboBox4.addItem(rs.getString("Descripcion"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void cargardetalle() {
        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        try {

            String SQL = "SELECT * FROM detalle_pedido";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                jComboBox1.addItem(rs.getString("id_detalle_pedido"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void cargaropsindpp(String npp) {
        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();

        String[] titulos = {"Cod orden de produccion", "Nombre del producto", "Cantidad pedido", "Fecha"};
        c.model = new DefaultTableModel(null, titulos);
        String op1[] = new String[5];

        try {

            String SQL = "SELECT id_orden_produccion,cantidad,fecha,id_detalle_pedido,descripcion from orden_de_produccion AS op JOIN producto p ON op.id_producto=p.id_producto where id_orden_produccion LIKE '%" + npp + "%' and statusbajaordprod is null and id_detalle_pedido is  null";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                op1[0] = rs.getString("id_orden_produccion");
                op1[1] = rs.getString("descripcion");
                op1[2] = rs.getString("cantidad");
                op1[3] = rs.getString("fecha");
                op1[4] = rs.getString("id_detalle_pedido");

                jComboBox2.addItem(rs.getString("id_orden_produccion"));

                c.model.addRow(op1);
                jTable1.setModel(c.model);

            }
        } catch (Exception e) {
            e.printStackTrace();
//JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
    }

    void cargar(String valor) {

        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();

        String[] titulos = {"Cod orden de produccion", "Nombre del producto", "Cantidad pedido", "Fecha", "Cod detalle receta"};
        c.model = new DefaultTableModel(null, titulos);
        String op[] = new String[5];

        try {

            String SQL = "SELECT id_orden_produccion,cantidad,fecha,id_detalle_pedido,descripcion from orden_de_produccion AS op JOIN producto p ON op.id_producto=p.id_producto where id_orden_produccion LIKE '%" + valor + "%'  and id_detalle_pedido IS NOT NULL and statusbajaordprod is null";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                op[0] = rs.getString("id_orden_produccion");
                op[1] = rs.getString("descripcion");
                op[2] = rs.getString("cantidad");
                op[3] = rs.getString("fecha");
                op[4] = rs.getString("id_detalle_pedido");

                jComboBox2.addItem(rs.getString("id_orden_produccion"));

                c.model.addRow(op);
                ordprod.setModel(c.model);

            }
        } catch (Exception e) {
            e.printStackTrace();
//JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
    }

    public static Connection getConexion() {

        Connection con = null;

        try {

            Class.forName("com.mysql.jdbc.Driver");

        } catch (Exception e) {
            System.out.println(e);

        }

        return con;
    }

    //_--------------------------------------------------------------------------------------------------------------------------------------------------
    //_--------------------------------------------------------------------------------------------------------------------------------------------------
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        ordprod = new javax.swing.JTable();
        jPanel13 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        producetxt = new javax.swing.JSpinner();
        jComboBox1 = new javax.swing.JComboBox<>();
        rSButtonMetro1 = new rsbuttom.RSButtonMetro();
        rSButtonMetro2 = new rsbuttom.RSButtonMetro();
        rSButtonMetro3 = new rsbuttom.RSButtonMetro();
        jLabel6 = new javax.swing.JLabel();
        rSButtonMetro4 = new rsbuttom.RSButtonMetro();
        jComboBox2 = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();
        jComboBox4 = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jSeparator7 = new javax.swing.JSeparator();
        jSeparator8 = new javax.swing.JSeparator();
        jCheckBox1 = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel4.setBackground(new java.awt.Color(230, 205, 141));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton2.setBackground(new java.awt.Color(230, 205, 141));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 12, 66, 53));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("Orden de Produccion");
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 10, -1, 42));

        ordprod.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(ordprod);

        jPanel13.setBackground(new java.awt.Color(244, 243, 239));
        jPanel13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel4.setText("Cantidad pedido");
        jPanel13.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, 30));

        jLabel5.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel5.setText("Buscar orden a modificar:");
        jPanel13.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 0, -1, 30));
        jPanel13.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 310, 10));
        jPanel13.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 310, 10));
        jPanel13.add(producetxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 160, 160, 30));

        jComboBox1.setEditable(true);
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar o buscar" }));
        jComboBox1.setToolTipText("");
        jComboBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox1ItemStateChanged(evt);
            }
        });
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        jPanel13.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 60, 160, 30));

        rSButtonMetro1.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro1.setForeground(new java.awt.Color(0, 0, 0));
        rSButtonMetro1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar.png"))); // NOI18N
        rSButtonMetro1.setText("Agregar");
        rSButtonMetro1.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro1.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro1.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro1.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro1.setColorTextPressed(new java.awt.Color(0, 0, 0));
        rSButtonMetro1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro1ActionPerformed(evt);
            }
        });
        jPanel13.add(rSButtonMetro1, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 80, 130, 50));

        rSButtonMetro2.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro2.setForeground(new java.awt.Color(0, 0, 0));
        rSButtonMetro2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar_1.png"))); // NOI18N
        rSButtonMetro2.setText("Modificar");
        rSButtonMetro2.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro2.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro2.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro2.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro2.setColorTextPressed(new java.awt.Color(0, 0, 0));
        rSButtonMetro2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro2ActionPerformed(evt);
            }
        });
        jPanel13.add(rSButtonMetro2, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 20, 130, 50));

        rSButtonMetro3.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro3.setForeground(new java.awt.Color(0, 0, 0));
        rSButtonMetro3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/eliminar.png"))); // NOI18N
        rSButtonMetro3.setText("Eliminar");
        rSButtonMetro3.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro3.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro3.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro3.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro3.setColorTextPressed(new java.awt.Color(0, 0, 0));
        rSButtonMetro3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro3ActionPerformed(evt);
            }
        });
        jPanel13.add(rSButtonMetro3, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 140, 130, 50));

        jLabel6.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel6.setText("Producto");
        jPanel13.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, 30));

        rSButtonMetro4.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro4.setForeground(new java.awt.Color(0, 0, 0));
        rSButtonMetro4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Boton-buscar.png"))); // NOI18N
        rSButtonMetro4.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro4.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro4.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro4.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro4.setColorTextPressed(new java.awt.Color(0, 0, 0));
        rSButtonMetro4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro4ActionPerformed(evt);
            }
        });
        jPanel13.add(rSButtonMetro4, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 50, 40, 40));

        jComboBox2.setEditable(true);
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jPanel13.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 30, 150, 30));

        jTextField1.setEditable(false);
        jPanel13.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 70, 150, 30));

        jComboBox4.setEditable(true);
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jPanel13.add(jComboBox4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 110, 160, 30));

        jLabel7.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel7.setText("Codigo del pedido");
        jPanel13.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, 30));
        jPanel13.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 310, 10));
        jPanel13.add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 310, 10));

        jCheckBox1.setText("Seleccionar si se carga sin pedido cliente");
        jCheckBox1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCheckBox1MouseClicked(evt);
            }
        });
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });
        jPanel13.add(jCheckBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 270, 30));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable1.setToolTipText("");
        jTable1.setName(""); // NOI18N
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 828, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void rSButtonMetro1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro1ActionPerformed
if(jCheckBox1.isSelected()==true){

  Date fecha = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fechaactual = sdf.format(fecha);

        int selectprod = (int) jComboBox4.getSelectedIndex();
Integer id = null;
         id = (Integer) jComboBox1.getSelectedIndex();
         //   jComboBox1.setSelectedIndex(-1);
     //  jComboBox1.insertItemAt("", 0);
        int produce = (int) producetxt.getValue();

        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        try {
            
            c.getConexion();
            c.ps = conn.prepareStatement("INSERT INTO orden_de_produccion(id_producto,cantidad,fecha) VALUES (?,?,?)");

            c.ps.setInt(1, selectprod);

            c.ps.setInt(2, produce);

            c.ps.setString(3, fechaactual);
        
            //c.ps.setInt(4, id);
          

            
            int res = c.ps.executeUpdate();
cargaropsindpp("");
          
            if (res > 0) {

                JOptionPane.showMessageDialog(null, "DATOS DE LA ORDEN SE MODIFICO CORRECTAMENTE");

            } else {
                JOptionPane.showMessageDialog(null, "LA ORDEN NO SE HA MODIFICADO CORRECTAMENTE");

            }

        } catch (Exception e) {
            e.printStackTrace();
            // System.err.println(e);
        }
        c.closeConexion();
}else{
        // TODO add your handling code here:
        Date fecha = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fechaactual = sdf.format(fecha);

        int selectprod = (int) jComboBox4.getSelectedIndex();
Integer id = null;
         id = (Integer) jComboBox1.getSelectedIndex();
         //   jComboBox1.setSelectedIndex(-1);
     //  jComboBox1.insertItemAt("", 0);
        int produce = (int) producetxt.getValue();

        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        try {
            
            c.getConexion();
            c.ps = conn.prepareStatement("INSERT INTO orden_de_produccion(id_producto,cantidad,fecha,id_detalle_pedido) VALUES (?,?,?,?)");

            c.ps.setInt(1, selectprod);

            c.ps.setInt(2, produce);

            c.ps.setString(3, fechaactual);
        
            c.ps.setInt(4, id);
          

            
            int res = c.ps.executeUpdate();

            cargar("");
            if (res > 0) {

                JOptionPane.showMessageDialog(null, "DATOS DE LA ORDEN SE MODIFICO CORRECTAMENTE");

            } else {
                JOptionPane.showMessageDialog(null, "LA ORDEN NO SE HA MODIFICADO CORRECTAMENTE");

            }

        } catch (Exception e) {
            e.printStackTrace();
            // System.err.println(e);
        }
        c.closeConexion();
    }//GEN-LAST:event_rSButtonMetro1ActionPerformed
   
    }
    
    private void rSButtonMetro2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro2ActionPerformed

        String selectprod = (String) jComboBox1.getSelectedItem();
        int produce = (int) producetxt.getValue();
        int id = (int) jComboBox2.getSelectedIndex();

        int respuesta = JOptionPane.showConfirmDialog(this, "¿ESTA SEGURO DE REALIZAR LOS CAMBIOS?", "confirm", JOptionPane.YES_NO_OPTION, HEIGHT);
        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        if (respuesta == JOptionPane.YES_OPTION) {
            c.getConexion();
            try {

                c.ps = conn.prepareStatement("UPDATE orden_de_produccion SET cantidad=?,descripcion=? where id_orden_produccion=? ");

                c.ps.setInt(1, produce);
                c.ps.setString(2, selectprod);
                c.ps.setInt(3, id);

                int res = c.ps.executeUpdate();

                if (res > 0) {
                    JOptionPane.showMessageDialog(null, "LOS DATOS HAN SIDO MODIFICADOS CORRECTAMENTE");

                } else {
                    JOptionPane.showMessageDialog(null, "EL PROVEEDOR NO SE HA MODIFICADO CORRECTAMENTE");

                }
                cargar("");

            } catch (Exception e) {
                // System.err.println(e);
                e.printStackTrace();
            }
            c.closeConexion();
        } else if (respuesta == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "SE HAN CANCELADO LOS CAMBIOS");
        }
    }//GEN-LAST:event_rSButtonMetro2ActionPerformed


    private void rSButtonMetro4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro4ActionPerformed
        // TODO add your handling code here:
        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        int nombreprod = jComboBox2.getSelectedIndex();
        c.getConexion();
        try {

            c.ps = conn.prepareStatement("SELECT * FROM orden_produccion WHERE id_orden_produccion=?");
            c.ps.setInt(1, nombreprod);

            c.rs = c.ps.executeQuery();

            if (c.rs.next()) {
                jTextField1.setText(c.rs.getString("descripcion"));
                producetxt.setValue(c.rs.getInt("cantidad"));

            } else {
                JOptionPane.showMessageDialog(null, "No existe orden de produccion con ese nombre");
            }

        } catch (Exception e) {
            e.printStackTrace();
// System.err.println(e);
        }

    }//GEN-LAST:event_rSButtonMetro4ActionPerformed

    private void rSButtonMetro3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro3ActionPerformed
        // TODO add your handling code here:

        Date fecha = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fechaactual = sdf.format(fecha);
        int fila = ordprod.getSelectedRow();

        int valor = parseInt(ordprod.getValueAt(fila, 0).toString());

        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        int respuesta = JOptionPane.showConfirmDialog(this, "¿ESTA SEGURO QUE DESEA ELIMINAR?", "ELIMINAR ELEMENTO", JOptionPane.YES_NO_OPTION, HEIGHT);

        if (respuesta == JOptionPane.YES_OPTION) {
            if (fila >= 0) {
                c.getConexion();
                try {

                    c.ps = conn.prepareStatement("UPDATE orden_de_produccion SET statusbajaordprod=? WHERE id_orden_produccion=" + valor);

                    c.ps.setString(1, fechaactual);
                    int res = c.ps.executeUpdate();
                    if (res > 0) {
                        JOptionPane.showMessageDialog(null, "Orden de produccion dado de baja");
                        cargar("");
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "La orden de produccion no se ha podido dar de baja");
                }
            }
        } else if (respuesta == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "SE HAN CANCELADO LOS CAMBIOS");
        }
    }//GEN-LAST:event_rSButtonMetro3ActionPerformed

    private void jComboBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox1ItemStateChanged
        // TODO add your handling code here:
        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        Integer filtro = (Integer) jComboBox1.getSelectedIndex();

        String[] titulos = {" "};
        c.model = new DefaultTableModel(null, titulos);
        String op[] = new String[5];
        String producto = (String) jComboBox4.getSelectedItem();
        int cantidad = (int) producetxt.getValue();

        try {

            String SQL = "SELECT cantidad,id_detalle_pedido,descripcion from detalle_pedido AS dp JOIN producto p ON dp.id_producto=p.id_producto where id_detalle_pedido=" + filtro;

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                jComboBox4.setSelectedItem(rs.getString("descripcion"));

                producetxt.setValue(rs.getInt("cantidad"));
                //  this.jComboBox4.addItem(rs.getString("descripcion"));
                //  this.producetxt.setValue("dp.cantidad");

            }
        } catch (Exception e) {
            e.printStackTrace();
            //JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }

    }//GEN-LAST:event_jComboBox1ItemStateChanged

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jCheckBox1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCheckBox1MouseClicked
        // TODO add your handling code here:
        if(jCheckBox1.isSelected()==true){
             jComboBox1.setEnabled(false);
            
 jLabel7.setEnabled(false);
        }else{
              jComboBox1.setEnabled(true);
 jLabel7.setEnabled(true);
        }
    }//GEN-LAST:event_jCheckBox1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaOrdenDeProduccion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaOrdenDeProduccion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaOrdenDeProduccion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaOrdenDeProduccion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PantallaOrdenDeProduccion().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTable ordprod;
    private javax.swing.JSpinner producetxt;
    private rsbuttom.RSButtonMetro rSButtonMetro1;
    private rsbuttom.RSButtonMetro rSButtonMetro2;
    private rsbuttom.RSButtonMetro rSButtonMetro3;
    private rsbuttom.RSButtonMetro rSButtonMetro4;
    // End of variables declaration//GEN-END:variables
}
