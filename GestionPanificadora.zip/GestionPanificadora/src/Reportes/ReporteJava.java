
package Reportes;

/**
 *
 * @author Ian
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;

import java.sql.Connection;

/**
 *
 * @author Santi
 */
public class ReporteJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        // TODO code application logic here
        String informeOrigen = "E:\\Practicas Java 2022\\Panificadora8-12\\src\\Reportes\\reporteProv.jrxml";

        String informeDestino = "E:\\Practicas Java 2022\\Panificadora8-12\\src\\Reportes\\reporteProv.pdf";
        Connection conexion = null;

        try {
            System.out.println("PROBANDO CONEXION...");
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/panificadora", "root", "");
            conexion.setAutoCommit(false);
            if (conexion != null) {
                System.out.println("conexion correcta");
            }

        } catch (Exception e) {
            System.out.println("ERROR DE CONEXION");
        }
        try {
            //compila el archivo generado con extension jrxml
            JasperReport jasperReport = JasperCompileManager.compileReport(informeOrigen);
            //habilita la conexion
            Class.forName("mysql-connector-java-5.1.13-bin.jar");
            //crear nuestro informe con JasperReport
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, conexion);
            
              System.out.println("Generando informe...");
            //exportar al formato que deseemos (PDF en este caso)
            JasperExportManager.exportReportToPdf(jasperPrint);

            //visualizar el archivo generado con JasperViewer
            JasperViewer.viewReport(jasperPrint);

        } catch (JRException ex) {
            System.err.println(ex.getMessage());
        }
    }

}