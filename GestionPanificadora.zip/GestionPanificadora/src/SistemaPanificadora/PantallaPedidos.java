package SistemaPanificadora;

import java.awt.Dimension;
import java.awt.Toolkit;
import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Santi
 */
public class PantallaPedidos extends javax.swing.JFrame {

    private Object nombre;

    /**
     * Creates new form PantallaPedidos
     */
    public PantallaPedidos() {
        SpinnerNumberModel nm = new SpinnerNumberModel();

        initComponents();
        AutoCompleteDecorator.decorate(this.selectprod);
        AutoCompleteDecorator.decorate(this.jComboBox6);
        AutoCompleteDecorator.decorate(this.jComboBox7);
        AutoCompleteDecorator.decorate(this.jComboBox4);
        AutoCompleteDecorator.decorate(this.jComboBox9);
        AutoCompleteDecorator.decorate(this.unimedmod);


        AutoCompleteDecorator.decorate(this.jComboBox14);

        AutoCompleteDecorator.decorate(this.jComboBox14);

        Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();

        this.setLocationRelativeTo(null);
        cargarpedido("");
        cargarprovped();
        cargarproducto();
        cargarcliente();
        cargar("");
        cargardetalleproveedor("");

        cargarproveedor();
        cargarmp();
        jComboBox7.setEnabled(false);
        jSpinner2.setEnabled(false);
        generarpedido3.setEnabled(false);
    }

    void resercombobox() {
        selectprod.setSelectedIndex(0);
        jComboBox6.setSelectedIndex(0);
        jComboBox7.setSelectedIndex(0);
        jComboBox4.setSelectedIndex(0);
        jComboBox9.setSelectedIndex(0);

        jComboBox14.setSelectedIndex(0);
       
        jSpinner2.setValue(0);

    }

    void cargarprovped() {
        Conexion con = new Conexion();
        Connection conn = con.getConexion();

        String mp[] = new String[8];
        String[] titulos2 = {""};
        con.model = new DefaultTableModel(null, titulos2);
        try {
            con.getConexion();
            String SQL = "SELECT * FROM pedido_a_proveedor WHERE  statusbajapedprov is null";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

          
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();

    }

    void cargarmp() {
        Conexion con = new Conexion();
        Connection conn = con.getConexion();

        String mp[] = new String[8];
        String[] titulos2 = {""};
        con.model = new DefaultTableModel(null, titulos2);
        try {
            con.getConexion();
            String SQL = "SELECT * FROM `materia_prima` WHERE  statusbajamp is null";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                jComboBox7.addItem(rs.getString("descripcion"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }

    void cargarpedido(String Valor) {
        Conexion con = new Conexion();
        Connection conn = con.getConexion();
        con.getConexion();
        //carga de detalle pedido al cliente

        String Pedidos[] = new String[7];

        String[] titulos = {"cod pedido cliente", "nombre del cliente", "Producto", "Cantidad", "Unidad Medida", "estado", "fecha"};
        con.model = new DefaultTableModel(null, titulos);
        try {

            String SQL = "select pdc.id_pedido_cliente,cantidad,statusbajadt,estado,fecha,statusbajapedcl,nombre,statusbajacl,descripcion,unidad_medida FROM pedido_cliente AS pdc JOIN detalle_pedido dtp ON pdc.id_pedido_cliente=dtp.id_pedido_cliente JOIN producto p ON dtp.id_producto=p.id_producto JOIN cliente cl ON pdc.id_cliente= cl.id_cliente LIKE '%" + Valor + "%'  AND statusbajapedcl is null";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                Pedidos[0] = rs.getString("pdc.id_pedido_cliente");
                Pedidos[1] = rs.getString("nombre");
                Pedidos[2] = rs.getString("descripcion");
                Pedidos[3] = rs.getString("cantidad");
                Pedidos[4] = rs.getString("unidad_medida");
                Pedidos[5] = rs.getString("pdc.estado");
                Pedidos[6] = rs.getString("pdc.fecha");

                jComboBox6.addItem(rs.getString("id_pedido_cliente"));
                jComboBox2.addItem(rs.getString("descripcion"));
                jComboBox1.addItem(rs.getString("estado"));

                con.model.addRow(Pedidos);

                table1.setModel(con.model);
                tablaPedClie.setModel(con.model);
                con.getConexion();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }
    //cargar detalle pedido

//Carga BBDD Pedido Proveedor/*/*/*/*/*//*/*/*/*/*/*/
    void cargar(String provalor) {
        //proveedores

        Conexion con = new Conexion();
        Connection conn = con.getConexion();

        String pedidosProv[] = new String[3];
        String[] titulos2 = {"Cod pedido proveedor", "Fecha", "Proveedor"};
        con.model = new DefaultTableModel(null, titulos2);
        try {
            con.getConexion();
            String SQL = "select id_pedido_proveedor,nombre,fecha,pprov.id_proveedor from pedido_a_proveedor AS pprov JOIN proveedor p ON pprov.id_proveedor = p.id_proveedor where id_pedido_proveedor LIKE '%" + provalor + "%' and statusbajapedprov is null";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                pedidosProv[0] = rs.getString("id_pedido_proveedor");
                pedidosProv[1] = rs.getString("nombre");
                pedidosProv[2] = rs.getString("fecha");

                jComboBox4.addItem(rs.getString("id_pedido_proveedor"));

                jComboBox11.addItem(rs.getString("nombre"));

                con.model.addRow(pedidosProv);
                jTable1.setModel(con.model);
                con.getConexion();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }
//carga detalle pedido proveedor

    void cargardetalleproveedor(String cdtp) {
        Conexion con = new Conexion();
        Connection conn = con.getConexion();
        

        String detalleProv[] = new String[3];
        String[] titulos4 = {"Cod detalle pedido proveedor", "Ingrediente ", "Cantidad",};
        con.model = new DefaultTableModel(null, titulos4);
        try {
            con.getConexion();
            String SQL = "SELECT  id_detalle_pedido_proveedor,descripcion,cantidad,id_pedido_proveedor FROM detalle_pedido_proveedor AS dpp JOIN materia_prima mp ON dpp.id_materia_prima=mp.id_materia_prima LIKE '%" + cdtp + "%' and statusbajadtpedprov is null";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                detalleProv[0] = rs.getString("id_detalle_pedido_proveedor");
                detalleProv[1] = rs.getString("descripcion");
                detalleProv[2] = rs.getString("cantidad");

                con.model.addRow(detalleProv);
                jTable3.setModel(con.model);

                jComboBox9.addItem(rs.getString("descripcion"));
                con.getConexion();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }
//carga los datos del producto

    void cargarproducto() {
        Conexion con = new Conexion();
        Connection conn = con.getConexion();

        try {
            con.getConexion();
            String SQL = "SELECT * from producto where statusbajaProd is null ";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                selectprod.addItem(rs.getString("descripcion"));

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }

    void cargarcliente() {

        Conexion con = new Conexion();
        Connection conn = con.getConexion();
        try {
            con.getConexion();
            String SQL = "SELECT *from cliente where statusbajacl is null ";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                jComboBox5.addItem(rs.getString("nombre"));
                jComboBox3.addItem(rs.getString("nombre"));

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }

    void cargarproveedor() {
        Conexion con = new Conexion();
        Connection conn = con.getConexion();

        try {

            con.getConexion();
            String SQL = "SELECT *from proveedor  ";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                jComboBox14.addItem(rs.getString("nombre"));

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pantallaProveedor = new javax.swing.JFrame();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel12 = new javax.swing.JPanel();
        MPbotonMateriaPrima4 = new rsbuttom.RSButtonMetro();
        MPbotonMateriaPrima3 = new rsbuttom.RSButtonMetro();
        MPbotonMateriaPrima6 = new rsbuttom.RSButtonMetro();
        jComboBox11 = new javax.swing.JComboBox<>();
        nuevoPedidoProveedor = new javax.swing.JFrame();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jComboBox7 = new javax.swing.JComboBox<>();
        jSpinner2 = new javax.swing.JSpinner();
        generarpedido3 = new rsbuttom.RSButtonMetro();
        jPanel18 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jComboBox14 = new javax.swing.JComboBox<>();
        generarpedido1 = new rsbuttom.RSButtonMetro();
        MPbotonMateriaPrima9 = new rsbuttom.RSButtonMetro();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        modificarPedido = new javax.swing.JFrame();
        jPanel6 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        MPbotonMateriaPrima7 = new rsbuttom.RSButtonMetro();
        MPbotonMateriaPrima8 = new rsbuttom.RSButtonMetro();
        jPanel15 = new javax.swing.JPanel();
        jSeparator8 = new javax.swing.JSeparator();
        jSeparator7 = new javax.swing.JSeparator();
        jSeparator9 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jLabel13 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        unimedmod = new javax.swing.JComboBox<>();
        jComboBox9 = new javax.swing.JComboBox<>();
        jSpinner3 = new javax.swing.JSpinner();
        jLabel34 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jComboBox4 = new javax.swing.JComboBox<>();
        ModificarPedCLiente = new javax.swing.JFrame();
        jPanel10 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jButton9 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel21 = new javax.swing.JLabel();
        jSeparator14 = new javax.swing.JSeparator();
        jLabel25 = new javax.swing.JLabel();
        jSeparator13 = new javax.swing.JSeparator();
        jLabel20 = new javax.swing.JLabel();
        jSeparator12 = new javax.swing.JSeparator();
        jSeparator11 = new javax.swing.JSeparator();
        jSeparator10 = new javax.swing.JSeparator();
        jLabel24 = new javax.swing.JLabel();
        jSeparator15 = new javax.swing.JSeparator();
        umed = new javax.swing.JComboBox<>();
        jSeparator23 = new javax.swing.JSeparator();
        jLabel26 = new javax.swing.JLabel();
        jComboBox5 = new javax.swing.JComboBox<>();
        jComboBox6 = new javax.swing.JComboBox<>();
        rSButtonMetro5 = new rsbuttom.RSButtonMetro();
        jSpinner1 = new javax.swing.JSpinner();
        jLabel29 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        MPbotonMateriaPrima11 = new rsbuttom.RSButtonMetro();
        modifrpedcliente2 = new rsbuttom.RSButtonMetro();
        NuevoPedClie = new javax.swing.JFrame();
        jPanel23 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jSeparator18 = new javax.swing.JSeparator();
        jSeparator19 = new javax.swing.JSeparator();
        jLabel38 = new javax.swing.JLabel();
        jSeparator26 = new javax.swing.JSeparator();
        jLabel36 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        rSButtonMetro2 = new rsbuttom.RSButtonMetro();
        MPbotonMateriaPrima10 = new rsbuttom.RSButtonMetro();
        rSButtonMetro8 = new rsbuttom.RSButtonMetro();
        jPanel17 = new javax.swing.JPanel();
        jSpinField3 = new com.toedter.components.JSpinField();
        jLabel27 = new javax.swing.JLabel();
        selectprod = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jPanel11 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        PantallaClientes = new javax.swing.JFrame();
        jPanel25 = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        jButton11 = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tablaPedClie = new javax.swing.JTable();
        rSButtonMetro3 = new rsbuttom.RSButtonMetro();
        rSButtonMetro4 = new rsbuttom.RSButtonMetro();
        rSButtonMetro6 = new rsbuttom.RSButtonMetro();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel13 = new javax.swing.JPanel();
        botonPedidosProveedor = new rsbuttom.RSButtonMetro();
        rSButtonMetro1 = new rsbuttom.RSButtonMetro();
        MPbotonMateriaPrima12 = new rsbuttom.RSButtonMetro();

        pantallaProveedor.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(230, 205, 141));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel4.setFont(new java.awt.Font("Roboto Thin", 1, 36)); // NOI18N
        jLabel4.setText("Pedidos Proveedor");

        jButton2.setBackground(new java.awt.Color(230, 205, 141));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(228, 228, 228)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(251, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pantallaProveedor.getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 80));

        jPanel5.setBackground(new java.awt.Color(244, 243, 239));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jPanel5.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 780, 200));

        jPanel12.setBackground(new java.awt.Color(244, 243, 239));
        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "¿Que Desea Hacer?", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto Thin", 1, 14))); // NOI18N

        MPbotonMateriaPrima4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar_1.png"))); // NOI18N
        MPbotonMateriaPrima4.setText("Modificar Pedido");
        MPbotonMateriaPrima4.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima4.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima4.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima4.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima4.setColorTextPressed(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima4.setDefaultCapable(false);
        MPbotonMateriaPrima4.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        MPbotonMateriaPrima4.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima4.setIconTextGap(25);
        MPbotonMateriaPrima4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima4ActionPerformed(evt);
            }
        });

        MPbotonMateriaPrima3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Ordenproduccion.png"))); // NOI18N
        MPbotonMateriaPrima3.setText("Generar Pedido");
        MPbotonMateriaPrima3.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima3.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima3.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima3.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima3.setColorTextPressed(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima3.setDefaultCapable(false);
        MPbotonMateriaPrima3.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        MPbotonMateriaPrima3.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima3.setIconTextGap(25);
        MPbotonMateriaPrima3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima3ActionPerformed(evt);
            }
        });

        MPbotonMateriaPrima6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima6.setText("Volver Al Home");
        MPbotonMateriaPrima6.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima6.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima6.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima6.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima6.setColorTextPressed(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima6.setDefaultCapable(false);
        MPbotonMateriaPrima6.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        MPbotonMateriaPrima6.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima6.setIconTextGap(25);
        MPbotonMateriaPrima6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MPbotonMateriaPrima3, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(MPbotonMateriaPrima6, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(MPbotonMateriaPrima4, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MPbotonMateriaPrima3, javax.swing.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE)
                    .addComponent(MPbotonMateriaPrima6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(MPbotonMateriaPrima4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel5.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, 730, 110));

        jComboBox11.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jComboBox11.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox11ItemStateChanged(evt);
            }
        });
        jPanel5.add(jComboBox11, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 10, 150, -1));

        pantallaProveedor.getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 870, 420));

        jPanel7.setBackground(new java.awt.Color(244, 243, 239));
        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel7.setLayout(null);

        jPanel8.setBackground(new java.awt.Color(230, 205, 141));
        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButton3.setBackground(new java.awt.Color(230, 205, 141));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Roboto Thin", 1, 24)); // NOI18N
        jLabel5.setText("Generar Descripcion Pedido Proveedor");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 157, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(138, 138, 138)
                .addComponent(jLabel5)
                .addContainerGap(252, Short.MAX_VALUE))
            .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.add(jPanel8);
        jPanel8.setBounds(0, 0, 890, 70);

        jPanel14.setBackground(new java.awt.Color(244, 243, 239));
        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Detalle del pedido a proveedor", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Roboto Thin", 1, 14))); // NOI18N
        jPanel14.setLayout(null);

        jLabel6.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel6.setText("Seleccionar ingrediente");
        jPanel14.add(jLabel6);
        jLabel6.setBounds(10, 30, 220, 30);

        jLabel16.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel16.setText("Ingrese la cantidad:");
        jPanel14.add(jLabel16);
        jLabel16.setBounds(20, 90, 170, 30);
        jPanel14.add(jSeparator3);
        jSeparator3.setBounds(0, 140, 450, 10);
        jPanel14.add(jSeparator4);
        jSeparator4.setBounds(0, 70, 420, 10);

        jComboBox7.setEditable(true);
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar o escribir" }));
        jPanel14.add(jComboBox7);
        jComboBox7.setBounds(250, 30, 160, 30);
        jPanel14.add(jSpinner2);
        jSpinner2.setBounds(250, 90, 160, 30);

        generarpedido3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        generarpedido3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar.png"))); // NOI18N
        generarpedido3.setText("Generar Detalle Pedido");
        generarpedido3.setColorHover(new java.awt.Color(230, 205, 141));
        generarpedido3.setColorNormal(new java.awt.Color(244, 243, 239));
        generarpedido3.setColorPressed(new java.awt.Color(244, 237, 210));
        generarpedido3.setColorTextNormal(new java.awt.Color(0, 0, 0));
        generarpedido3.setDefaultCapable(false);
        generarpedido3.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        generarpedido3.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        generarpedido3.setIconTextGap(25);
        generarpedido3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                generarpedido3MouseClicked(evt);
            }
        });
        generarpedido3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generarpedido3ActionPerformed(evt);
            }
        });
        jPanel14.add(generarpedido3);
        generarpedido3.setBounds(120, 220, 240, 50);

        jPanel7.add(jPanel14);
        jPanel14.setBounds(420, 230, 460, 280);

        jPanel18.setBackground(new java.awt.Color(244, 243, 239));
        jPanel18.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Nuevo Pedido a Proveedor", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Roboto Thin", 1, 14))); // NOI18N
        jPanel18.setLayout(null);

        jLabel15.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel15.setText("Proveedor");
        jPanel18.add(jLabel15);
        jLabel15.setBounds(20, 100, 170, 30);

        jComboBox14.setEditable(true);
        jComboBox14.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jPanel18.add(jComboBox14);
        jComboBox14.setBounds(190, 100, 160, 30);

        generarpedido1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        generarpedido1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar.png"))); // NOI18N
        generarpedido1.setText("Generar Pedido");
        generarpedido1.setColorHover(new java.awt.Color(230, 205, 141));
        generarpedido1.setColorNormal(new java.awt.Color(244, 243, 239));
        generarpedido1.setColorPressed(new java.awt.Color(244, 237, 210));
        generarpedido1.setColorTextNormal(new java.awt.Color(0, 0, 0));
        generarpedido1.setDefaultCapable(false);
        generarpedido1.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        generarpedido1.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        generarpedido1.setIconTextGap(25);
        generarpedido1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                generarpedido1MouseClicked(evt);
            }
        });
        generarpedido1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generarpedido1ActionPerformed(evt);
            }
        });
        jPanel18.add(generarpedido1);
        generarpedido1.setBounds(90, 210, 190, 50);

        jPanel7.add(jPanel18);
        jPanel18.setBounds(20, 230, 400, 280);

        MPbotonMateriaPrima9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MPbotonMateriaPrima9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima9.setText("Volver al Home");
        MPbotonMateriaPrima9.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima9.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima9.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima9.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima9.setDefaultCapable(false);
        MPbotonMateriaPrima9.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        MPbotonMateriaPrima9.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima9.setIconTextGap(25);
        MPbotonMateriaPrima9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima9ActionPerformed(evt);
            }
        });
        jPanel7.add(MPbotonMateriaPrima9);
        MPbotonMateriaPrima9.setBounds(310, 520, 190, 50);

        jTable1.setAutoCreateRowSorter(true);
        jTable1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(jTable1);

        jPanel7.add(jScrollPane3);
        jScrollPane3.setBounds(0, 70, 420, 160);

        jTable3.setAutoCreateRowSorter(true);
        jTable3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane5.setViewportView(jTable3);

        jPanel7.add(jScrollPane5);
        jScrollPane5.setBounds(420, 70, 460, 160);

        nuevoPedidoProveedor.getContentPane().add(jPanel7, java.awt.BorderLayout.CENTER);

        modificarPedido.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(244, 243, 239));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel9.setBackground(new java.awt.Color(230, 205, 141));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButton4.setBackground(new java.awt.Color(230, 205, 141));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Roboto Thin", 1, 24)); // NOI18N
        jLabel14.setText("Modificar Pedido Proveedor");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(176, 176, 176)
                .addComponent(jLabel14)
                .addContainerGap(236, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel6.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 70));

        MPbotonMateriaPrima7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MPbotonMateriaPrima7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar_1.png"))); // NOI18N
        MPbotonMateriaPrima7.setText("Guardar Cambios");
        MPbotonMateriaPrima7.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima7.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima7.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima7.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima7.setDefaultCapable(false);
        MPbotonMateriaPrima7.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        MPbotonMateriaPrima7.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima7.setIconTextGap(10);
        MPbotonMateriaPrima7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima7ActionPerformed(evt);
            }
        });
        jPanel6.add(MPbotonMateriaPrima7, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 370, 193, 48));

        MPbotonMateriaPrima8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MPbotonMateriaPrima8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima8.setText("Volver al Home");
        MPbotonMateriaPrima8.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima8.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima8.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima8.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima8.setDefaultCapable(false);
        MPbotonMateriaPrima8.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        MPbotonMateriaPrima8.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima8.setIconTextGap(25);
        MPbotonMateriaPrima8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima8ActionPerformed(evt);
            }
        });
        jPanel6.add(MPbotonMateriaPrima8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, 199, 48));

        jPanel15.setBackground(new java.awt.Color(244, 243, 239));
        jPanel15.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Modificar Pedido", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto Thin", 1, 14))); // NOI18N
        jPanel15.setLayout(null);
        jPanel15.add(jSeparator8);
        jSeparator8.setBounds(40, 70, 400, 10);
        jPanel15.add(jSeparator7);
        jSeparator7.setBounds(40, 120, 400, 10);
        jPanel15.add(jSeparator9);
        jSeparator9.setBounds(40, 170, 400, 10);
        jPanel15.add(jSeparator6);
        jSeparator6.setBounds(40, 220, 400, 10);

        jLabel13.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel13.setText("Codigo del pedido:");
        jPanel15.add(jLabel13);
        jLabel13.setBounds(40, 30, 240, 30);

        jLabel8.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel8.setText("Ingrese cantidad:");
        jPanel15.add(jLabel8);
        jLabel8.setBounds(40, 130, 130, 30);

        unimedmod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jPanel15.add(unimedmod);
        unimedmod.setBounds(290, 180, 150, 30);

        jComboBox9.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jComboBox9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox9ActionPerformed(evt);
            }
        });
        jPanel15.add(jComboBox9);
        jComboBox9.setBounds(290, 80, 150, 30);
        jPanel15.add(jSpinner3);
        jSpinner3.setBounds(290, 130, 150, 30);

        jLabel34.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel34.setText("Ingrese unidad de medida:");
        jPanel15.add(jLabel34);
        jLabel34.setBounds(40, 180, 170, 27);

        jLabel22.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel22.setText("Ingrese nombre del ingrediente:");
        jPanel15.add(jLabel22);
        jLabel22.setBounds(40, 80, 230, 30);

        jComboBox4.setEditable(true);
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Buscar" }));
        jComboBox4.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox4ItemStateChanged(evt);
            }
        });
        jPanel15.add(jComboBox4);
        jComboBox4.setBounds(290, 30, 150, 30);

        jPanel6.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 110, 620, 250));

        modificarPedido.getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 450));

        jPanel10.setBackground(new java.awt.Color(244, 243, 239));
        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel10.setLayout(null);

        jPanel16.setBackground(new java.awt.Color(230, 205, 141));
        jPanel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButton9.setBackground(new java.awt.Color(230, 205, 141));
        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Roboto Thin", 1, 24)); // NOI18N
        jLabel19.setText("Modificar Pedido Cliente");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(128, 128, 128)
                .addComponent(jLabel19)
                .addContainerGap(209, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel19)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel10.add(jPanel16);
        jPanel16.setBounds(0, -3, 690, 80);

        jPanel19.setBackground(new java.awt.Color(244, 243, 239));
        jPanel19.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos Pedido:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto Light", 1, 14))); // NOI18N
        jPanel19.setLayout(null);
        jPanel19.add(jDateChooser1);
        jDateChooser1.setBounds(430, 220, 152, 30);

        jLabel21.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel21.setText("Cod pedido cliente");
        jPanel19.add(jLabel21);
        jLabel21.setBounds(80, 20, 180, 30);
        jPanel19.add(jSeparator14);
        jSeparator14.setBounds(80, 60, 500, 10);

        jLabel25.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel25.setText("Producto");
        jPanel19.add(jLabel25);
        jLabel25.setBounds(80, 270, 230, 30);
        jPanel19.add(jSeparator13);
        jSeparator13.setBounds(80, 110, 500, 10);

        jLabel20.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel20.setText("Cantidad");
        jPanel19.add(jLabel20);
        jLabel20.setBounds(80, 120, 216, 30);
        jPanel19.add(jSeparator12);
        jSeparator12.setBounds(80, 160, 500, 10);
        jPanel19.add(jSeparator11);
        jSeparator11.setBounds(80, 210, 500, 10);
        jPanel19.add(jSeparator10);
        jSeparator10.setBounds(80, 260, 500, 10);

        jLabel24.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel24.setText("Fecha");
        jPanel19.add(jLabel24);
        jLabel24.setBounds(80, 230, 200, 17);
        jPanel19.add(jSeparator15);
        jSeparator15.setBounds(80, 350, 500, 10);

        umed.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        umed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                umedActionPerformed(evt);
            }
        });
        jPanel19.add(umed);
        umed.setBounds(430, 170, 150, 30);
        jPanel19.add(jSeparator23);
        jSeparator23.setBounds(80, 260, 500, 10);

        jLabel26.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel26.setText("Cliente");
        jPanel19.add(jLabel26);
        jLabel26.setBounds(80, 70, 44, 30);

        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccioanar" }));
        jPanel19.add(jComboBox5);
        jComboBox5.setBounds(430, 70, 150, 30);

        jComboBox6.setEditable(true);
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jPanel19.add(jComboBox6);
        jComboBox6.setBounds(430, 20, 150, 30);

        rSButtonMetro5.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Boton-buscar.png"))); // NOI18N
        rSButtonMetro5.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro5ActionPerformed(evt);
            }
        });
        jPanel19.add(rSButtonMetro5);
        rSButtonMetro5.setBounds(610, 20, 40, 35);
        jPanel19.add(jSpinner1);
        jSpinner1.setBounds(430, 120, 150, 30);

        jLabel29.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel29.setText("Unidad Medida");
        jPanel19.add(jLabel29);
        jLabel29.setBounds(80, 170, 230, 30);

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });
        jPanel19.add(jComboBox2);
        jComboBox2.setBounds(430, 270, 150, 30);

        jPanel10.add(jPanel19);
        jPanel19.setBounds(10, 90, 660, 370);

        MPbotonMateriaPrima11.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima11.setText("Volver al Home");
        MPbotonMateriaPrima11.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima11.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima11.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima11.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima11.setDefaultCapable(false);
        MPbotonMateriaPrima11.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        MPbotonMateriaPrima11.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima11.setIconTextGap(25);
        MPbotonMateriaPrima11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima11ActionPerformed(evt);
            }
        });
        jPanel10.add(MPbotonMateriaPrima11);
        MPbotonMateriaPrima11.setBounds(20, 480, 199, 48);

        modifrpedcliente2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        modifrpedcliente2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar_1.png"))); // NOI18N
        modifrpedcliente2.setText("Modificar");
        modifrpedcliente2.setColorHover(new java.awt.Color(230, 205, 141));
        modifrpedcliente2.setColorNormal(new java.awt.Color(244, 243, 239));
        modifrpedcliente2.setColorPressed(new java.awt.Color(244, 237, 210));
        modifrpedcliente2.setColorTextNormal(new java.awt.Color(0, 0, 0));
        modifrpedcliente2.setColorTextPressed(new java.awt.Color(0, 0, 0));
        modifrpedcliente2.setDefaultCapable(false);
        modifrpedcliente2.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        modifrpedcliente2.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        modifrpedcliente2.setIconTextGap(25);
        modifrpedcliente2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifrpedcliente2ActionPerformed(evt);
            }
        });
        jPanel10.add(modifrpedcliente2);
        modifrpedcliente2.setBounds(440, 480, 227, 50);

        javax.swing.GroupLayout ModificarPedCLienteLayout = new javax.swing.GroupLayout(ModificarPedCLiente.getContentPane());
        ModificarPedCLiente.getContentPane().setLayout(ModificarPedCLienteLayout);
        ModificarPedCLienteLayout.setHorizontalGroup(
            ModificarPedCLienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, 688, Short.MAX_VALUE)
        );
        ModificarPedCLienteLayout.setVerticalGroup(
            ModificarPedCLienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, 550, Short.MAX_VALUE)
        );

        NuevoPedClie.getContentPane().setLayout(null);

        jPanel23.setBackground(new java.awt.Color(244, 243, 239));
        jPanel23.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel23.setLayout(null);

        jPanel24.setBackground(new java.awt.Color(244, 243, 239));
        jPanel24.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Ingrese el nuevo Pedido", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto Thin", 1, 14))); // NOI18N
        jPanel24.setLayout(null);
        jPanel24.add(jSeparator18);
        jSeparator18.setBounds(10, 120, 400, 10);
        jPanel24.add(jSeparator19);
        jSeparator19.setBounds(10, 60, 400, 10);

        jLabel38.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel38.setText("Telefono");
        jPanel24.add(jLabel38);
        jLabel38.setBounds(198, 600, 201, 17);
        jPanel24.add(jSeparator26);
        jSeparator26.setBounds(10, 160, 420, 10);

        jLabel36.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel36.setText("Cliente:");
        jPanel24.add(jLabel36);
        jLabel36.setBounds(10, 30, 207, 20);

        jComboBox3.setEditable(true);
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Buscar" }));
        jPanel24.add(jComboBox3);
        jComboBox3.setBounds(260, 30, 140, 22);

        jPanel23.add(jPanel24);
        jPanel24.setBounds(40, 130, 470, 220);

        rSButtonMetro2.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/lista.png"))); // NOI18N
        rSButtonMetro2.setText("Generar Pedido");
        rSButtonMetro2.setColorBorde(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro2.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro2.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro2.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro2.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro2.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        rSButtonMetro2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro2ActionPerformed(evt);
            }
        });
        jPanel23.add(rSButtonMetro2);
        rSButtonMetro2.setBounds(640, 360, 200, 50);

        MPbotonMateriaPrima10.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima10.setText("Volver al Home");
        MPbotonMateriaPrima10.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima10.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima10.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima10.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima10.setDefaultCapable(false);
        MPbotonMateriaPrima10.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        MPbotonMateriaPrima10.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima10.setIconTextGap(25);
        MPbotonMateriaPrima10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima10ActionPerformed(evt);
            }
        });
        jPanel23.add(MPbotonMateriaPrima10);
        MPbotonMateriaPrima10.setBounds(50, 360, 200, 50);

        rSButtonMetro8.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro8.setText("Nuevo Cliente");
        rSButtonMetro8.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro8.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro8.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro8.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro8ActionPerformed(evt);
            }
        });
        jPanel23.add(rSButtonMetro8);
        rSButtonMetro8.setBounds(360, 370, 140, 40);

        jPanel17.setBackground(new java.awt.Color(244, 243, 239));
        jPanel17.setBorder(javax.swing.BorderFactory.createTitledBorder("Detalle Pedido Cliente"));

        jLabel27.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel27.setText("Ingrese Cantidad que requiere:");

        selectprod.setEditable(true);
        selectprod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));

        jLabel3.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel3.setText("Ingrese el nombre del Producto:");

        jLabel35.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel35.setText("Estado:");

        jComboBox1.setEditable(true);
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecciona o escribe" }));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                        .addComponent(selectprod, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jSpinField3, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(34, 34, 34))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSpinField3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(selectprod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(42, Short.MAX_VALUE))
        );

        jPanel23.add(jPanel17);
        jPanel17.setBounds(520, 140, 500, 210);

        NuevoPedClie.getContentPane().add(jPanel23);
        jPanel23.setBounds(0, 80, 1030, 490);

        jPanel11.setBackground(new java.awt.Color(230, 205, 141));
        jPanel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel17.setFont(new java.awt.Font("Roboto Thin", 1, 24)); // NOI18N
        jLabel17.setText("Nuevo Pedido Cliente");

        jButton5.setBackground(new java.awt.Color(230, 205, 141));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(265, 265, 265)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(412, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        NuevoPedClie.getContentPane().add(jPanel11);
        jPanel11.setBounds(0, 0, 1030, 0);

        PantallaClientes.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel25.setBackground(new java.awt.Color(244, 243, 239));
        jPanel25.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPanel26.setBackground(new java.awt.Color(230, 205, 141));
        jPanel26.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButton11.setBackground(new java.awt.Color(230, 205, 141));
        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jLabel31.setFont(new java.awt.Font("Roboto Thin", 1, 24)); // NOI18N
        jLabel31.setText("Administrar Pedidos Clientes");

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel31)
                .addGap(273, 273, 273))
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel26Layout.createSequentialGroup()
                        .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel26Layout.createSequentialGroup()
                        .addComponent(jLabel31)
                        .addGap(20, 20, 20))))
        );

        jPanel27.setBackground(new java.awt.Color(244, 243, 239));

        tablaPedClie.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane4.setViewportView(tablaPedClie);

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 752, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        rSButtonMetro3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/lista.png"))); // NOI18N
        rSButtonMetro3.setText("Generar nuevo Pedido");
        rSButtonMetro3.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro3.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro3.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro3.setColorTextHover(new java.awt.Color(0, 0, 0));
        rSButtonMetro3.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro3.setColorTextPressed(new java.awt.Color(0, 0, 0));
        rSButtonMetro3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro3ActionPerformed(evt);
            }
        });

        rSButtonMetro4.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar_1.png"))); // NOI18N
        rSButtonMetro4.setText("Modificar Pedido");
        rSButtonMetro4.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro4.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro4.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro4.setColorTextHover(new java.awt.Color(0, 0, 0));
        rSButtonMetro4.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro4.setColorTextPressed(new java.awt.Color(0, 0, 0));
        rSButtonMetro4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro4ActionPerformed(evt);
            }
        });

        rSButtonMetro6.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro6.setForeground(new java.awt.Color(0, 0, 0));
        rSButtonMetro6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/eliminar.png"))); // NOI18N
        rSButtonMetro6.setText("Eliminar");
        rSButtonMetro6.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro6.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro6.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro6.setColorTextHover(new java.awt.Color(0, 0, 0));
        rSButtonMetro6.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro6.setColorTextPressed(new java.awt.Color(0, 0, 0));
        rSButtonMetro6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(rSButtonMetro3, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(rSButtonMetro6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(rSButtonMetro4, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addComponent(jPanel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rSButtonMetro4, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rSButtonMetro3, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rSButtonMetro6, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(58, Short.MAX_VALUE))
        );

        PantallaClientes.getContentPane().add(jPanel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 490));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(230, 205, 141));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Roboto Thin", 1, 36)); // NOI18N
        jLabel1.setText("Pedidos");

        jButton1.setBackground(new java.awt.Color(230, 205, 141));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(234, 234, 234)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(326, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 80));

        jPanel4.setBackground(new java.awt.Color(244, 243, 239));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(table1);

        jPanel4.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 53, 778, 150));

        jLabel2.setFont(new java.awt.Font("Roboto Thin", 1, 18)); // NOI18N
        jLabel2.setText("Pedidos Clientes:");
        jPanel4.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(11, 12, -1, 29));
        jPanel4.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 778, 10));

        jPanel13.setBackground(new java.awt.Color(244, 243, 239));
        jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Seleccione una Accion:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto Thin", 1, 14))); // NOI18N

        botonPedidosProveedor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonPedidosProveedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/camion.png"))); // NOI18N
        botonPedidosProveedor.setText("Pedidos Proveedor");
        botonPedidosProveedor.setColorBorde(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonPedidosProveedor.setColorHover(new java.awt.Color(230, 205, 141));
        botonPedidosProveedor.setColorNormal(new java.awt.Color(244, 243, 239));
        botonPedidosProveedor.setColorPressed(new java.awt.Color(244, 237, 210));
        botonPedidosProveedor.setColorTextHover(new java.awt.Color(0, 0, 0));
        botonPedidosProveedor.setColorTextNormal(new java.awt.Color(0, 0, 0));
        botonPedidosProveedor.setColorTextPressed(new java.awt.Color(0, 0, 0));
        botonPedidosProveedor.setDefaultCapable(false);
        botonPedidosProveedor.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        botonPedidosProveedor.setIconTextGap(10);
        botonPedidosProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonPedidosProveedorActionPerformed(evt);
            }
        });

        rSButtonMetro1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/usuario_1.png"))); // NOI18N
        rSButtonMetro1.setText("Administrar Pedidos Cliente");
        rSButtonMetro1.setColorBorde(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro1.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro1.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro1.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro1.setColorTextHover(new java.awt.Color(0, 0, 0));
        rSButtonMetro1.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro1.setColorTextPressed(new java.awt.Color(0, 0, 0));
        rSButtonMetro1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro1ActionPerformed(evt);
            }
        });

        MPbotonMateriaPrima12.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima12.setText("Volver Al Home");
        MPbotonMateriaPrima12.setColorBorde(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima12.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima12.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima12.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima12.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima12.setColorTextPressed(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima12.setDefaultCapable(false);
        MPbotonMateriaPrima12.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        MPbotonMateriaPrima12.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima12.setIconTextGap(25);
        MPbotonMateriaPrima12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima12ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(rSButtonMetro1, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 285, Short.MAX_VALUE)
                .addComponent(botonPedidosProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
            .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel13Layout.createSequentialGroup()
                    .addGap(274, 274, 274)
                    .addComponent(MPbotonMateriaPrima12, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(274, Short.MAX_VALUE)))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonPedidosProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rSButtonMetro1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
            .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel13Layout.createSequentialGroup()
                    .addGap(23, 23, 23)
                    .addComponent(MPbotonMateriaPrima12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(24, 24, 24)))
        );

        jPanel4.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 770, -1));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 800, 420));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void botonPedidosProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonPedidosProveedorActionPerformed
        dispose();
        pantallaProveedor.setVisible(true);
        this.setVisible(false);
        pantallaProveedor.setSize(817, 540);
        pantallaProveedor.setResizable(false);
        pantallaProveedor.setLocationRelativeTo(null);

        PantallaPedidos home = new PantallaPedidos();
        home.setVisible(false);


    }//GEN-LAST:event_botonPedidosProveedorActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        pantallaProveedor.setVisible(false);
        PantallaPedidos home = new PantallaPedidos();
        home.setVisible(true);
        this.setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        dispose();
        nuevoPedidoProveedor.setVisible(false);
        pantallaProveedor.setVisible(true);

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        dispose();
        modificarPedido.setVisible(false);
        pantallaProveedor.setVisible(true);


    }//GEN-LAST:event_jButton4ActionPerformed

    private void MPbotonMateriaPrima7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima7ActionPerformed

        int pedidoproveedor = jComboBox9.getSelectedIndex();
        String unidadmed = (String) unimedmod.getSelectedItem();
        int canpedprov = (int) jSpinner3.getValue();
        int idprov = (int) jComboBox9.getSelectedIndex();
        int id = (int) jComboBox4.getSelectedIndex();
        int id2 = (int) jComboBox4.getSelectedIndex();

        Conexion con = new Conexion();
        Connection conn = con.getConexion();
        //actualiza los datos del pedido proveedor
        try {

            con.ps = conn.prepareStatement("UPDATE pedido_a_proveedor SET  where id_pedido_proveedor=?");

            con.ps.setInt(1, id);//combobox

            int res = con.ps.executeUpdate();

        } catch (Exception e) {
            System.err.println(e);
        }
        //---------------------------------------------------------------------------------------------------------------------------------------------------

        try {

            con.ps = conn.prepareStatement("UPDATE detalle_pedido_proveedor SET cantidad=? where id_detalle_pedido_proveedor=? ");
            con.ps.setInt(1, canpedprov);//jspin
            con.ps.setInt(2, id2);//jspin

            int res = con.ps.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "LOS DATOS HAN SIDO MODIFICADOS CORRECTAMENTE");
                cargarproveedor();
            } else {
                JOptionPane.showMessageDialog(null, "EL PROVEEDOR NO SE HA MODIFICADO CORRECTAMENTE");

            }
            cargar("");

        } catch (Exception e) {
            System.err.println(e);
        }
        con.closeConexion();
    }//GEN-LAST:event_MPbotonMateriaPrima7ActionPerformed

    private void MPbotonMateriaPrima8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima8ActionPerformed
        dispose();
        pantallaInicio home = new pantallaInicio();// TODO add your handling code here:
        home.setVisible(true);
        modificarPedido.setVisible(false);

    }//GEN-LAST:event_MPbotonMateriaPrima8ActionPerformed

    private void MPbotonMateriaPrima3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima3ActionPerformed

        pantallaProveedor.setVisible(false);
        nuevoPedidoProveedor.setVisible(true);
        nuevoPedidoProveedor.setSize(899, 590);
        nuevoPedidoProveedor.setResizable(false);
        nuevoPedidoProveedor.setLocationRelativeTo(null);

    }//GEN-LAST:event_MPbotonMateriaPrima3ActionPerformed

    private void MPbotonMateriaPrima4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima4ActionPerformed

        pantallaProveedor.setVisible(false);
        modificarPedido.setVisible(true);
        modificarPedido.setSize(818, 490);
        modificarPedido.setResizable(false);
        modificarPedido.setLocationRelativeTo(null);
    }//GEN-LAST:event_MPbotonMateriaPrima4ActionPerformed

    private void MPbotonMateriaPrima10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima10ActionPerformed
        NuevoPedClie.setVisible(false);

        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);
        this.setVisible(false);

        cargar("");
    }//GEN-LAST:event_MPbotonMateriaPrima10ActionPerformed

    private void rSButtonMetro1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro1ActionPerformed

        dispose();
        PantallaClientes.setVisible(true);
        PantallaClientes.setSize(774, 490);
        PantallaClientes.setLocationRelativeTo(null);
        PantallaClientes.setResizable(false);
    }//GEN-LAST:event_rSButtonMetro1ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        PantallaClientes.setVisible(false);

        PantallaPedidos home = new PantallaPedidos();
        home.setVisible(true);
    }//GEN-LAST:event_jButton11ActionPerformed

    private void rSButtonMetro3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro3ActionPerformed

        PantallaClientes.setVisible(false);
        NuevoPedClie.setVisible(true);
        NuevoPedClie.setSize(916, 560);
        NuevoPedClie.setResizable(false);
        NuevoPedClie.setLocationRelativeTo(null);
    }//GEN-LAST:event_rSButtonMetro3ActionPerformed

    private void rSButtonMetro4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro4ActionPerformed

        PantallaClientes.setVisible(false);
        ModificarPedCLiente.setVisible(true);
        ModificarPedCLiente.setSize(699, 590);
        ModificarPedCLiente.setLocationRelativeTo(null);
        ModificarPedCLiente.setResizable(false);
    }//GEN-LAST:event_rSButtonMetro4ActionPerformed

    private void MPbotonMateriaPrima11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima11ActionPerformed
        ModificarPedCLiente.setVisible(false);
        PantallaClientes.setVisible(false);
        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);

        cargar("");
    }//GEN-LAST:event_MPbotonMateriaPrima11ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        NuevoPedClie.setVisible(false);
        PantallaClientes.setVisible(true);

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed

        ModificarPedCLiente.setVisible(false);
        PantallaClientes.setVisible(true);
    }//GEN-LAST:event_jButton9ActionPerformed

    private void MPbotonMateriaPrima6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima6ActionPerformed
        pantallaProveedor.setVisible(false);
        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);
    }//GEN-LAST:event_MPbotonMateriaPrima6ActionPerformed

    private void MPbotonMateriaPrima12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima12ActionPerformed
        dispose();
        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);


    }//GEN-LAST:event_MPbotonMateriaPrima12ActionPerformed

    private void rSButtonMetro2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro2ActionPerformed
        Conexion con = new Conexion();
        Connection conn = con.getConexion();
        con.getConexion();
        try {

            Date fecha = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fechaactual = sdf.format(fecha);

            int cliente = (int) jComboBox3.getSelectedIndex();

            String prod = (String) selectprod.getSelectedItem();
            String estado = (String) jComboBox1.getSelectedItem();

            con.ps = conn.prepareStatement("INSERT INTO pedido_cliente(fecha,estado,id_cliente) VALUES (?,?,?)");

            con.ps.setString(1, fechaactual);

            con.ps.setString(2, estado);
            con.ps.setInt(3, cliente);

            con.ps.executeUpdate();

        } catch (Exception e) {
            System.err.println(e);
        }
        int id = 1;

        try {

            con.ps = conn.prepareStatement("select max(id_pedido_cliente) from detalle_pedido");
            con.rs = con.ps.executeQuery();
            while (con.rs.next()) {
                id = con.rs.getInt(1) + 1;

            }

        } catch (Exception e) {
            System.err.println(e);
        }

        try {

            int cantidad = (int) jSpinField3.getValue();

            int prod = (int) selectprod.getSelectedIndex();

            con.ps = conn.prepareStatement("INSERT INTO detalle_pedido(cantidad,id_producto,id_pedido_cliente) VALUES (?,?,?)");

            con.ps.setInt(1, cantidad);
            con.ps.setInt(2, prod);
            con.ps.setInt(3, id);

            int res = con.ps.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "El pedido cliente se genero correctamente");
                cargarpedido("");
            }

        } catch (Exception e) {
            System.err.println(e);
        }
        con.closeConexion();


    }//GEN-LAST:event_rSButtonMetro2ActionPerformed

    private void modifrpedcliente2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifrpedcliente2ActionPerformed
        // TODO add your handling code here:
        Conexion con = new Conexion();
        Connection conn = con.getConexion();
        con.getConexion();
        String dia = Integer.toString(jDateChooser1.getCalendar().get(Calendar.DAY_OF_MONTH));
        String mes = Integer.toString(jDateChooser1.getCalendar().get(Calendar.MONTH) + 1);
        String year = Integer.toString(jDateChooser1.getCalendar().get(Calendar.YEAR));
        String fecha = (year + "-" + mes + "-" + dia);

        int valor = (int) jSpinner1.getValue();
        int selectcliente = (int) jComboBox5.getSelectedIndex();

        int prod = (int) jComboBox2.getSelectedIndex();
        int pedcliente = (int) jComboBox6.getSelectedIndex();
        int dettalleped = (int) jComboBox6.getSelectedIndex();

        String unidadm = (String) umed.getSelectedItem();

        try {

            con.ps = conn.prepareStatement("UPDATE pedido_cliente SET id_cliente? ");

            con.ps.setInt(1, selectcliente);

            int res = con.ps.executeUpdate();

        } catch (Exception e) {
            System.err.println(e);
        }
        try {

            con.ps = conn.prepareStatement("UPDATE detalle_pedido SET cantidad=?,unidad_medida=?,id_producto=? ");

            con.ps.setInt(1, valor);
            con.ps.setString(2, unidadm);
            con.ps.setInt(3, prod);

            int res = con.ps.executeUpdate();

            if (res > 0) {
                JOptionPane.showMessageDialog(null, "LOS DATOS HAN SIDO MODIFICADOS CORRECTAMENTE");
                cargar("");
            } else {
                JOptionPane.showMessageDialog(null, "EL PROVEEDOR NO SE HA MODIFICADO CORRECTAMENTE");

            }

        } catch (Exception e) {
            System.err.println(e);
        }
        con.closeConexion();
    }//GEN-LAST:event_modifrpedcliente2ActionPerformed

    private void rSButtonMetro5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro5ActionPerformed
        // TODO add your handling code here:
        Conexion con = new Conexion();
        Connection conn = con.getConexion();
        con.getConexion();

        int pedcliente = (int) jComboBox6.getSelectedIndex();
        String unidadmed = (String) umed.getSelectedItem();

        try {

            con.ps = conn.prepareStatement("SELECT  pdc.id_pedido_cliente,pdc.fecha,cl.nombre,cl.id_cliente,dp.cantidad,dp.id_producto,dp.unidad_medida FROM `detalle_pedido` AS dp join pedido_cliente pdc ON dp.id_pedido_cliente = pdc.id_pedido_cliente JOIN cliente cl ON pdc.id_cliente = cl.id_cliente WHERE pdc.id_pedido_cliente=?");
            con.ps.setInt(1, pedcliente);
            System.out.println("pedido cliente " + pedcliente);

            con.rs = con.ps.executeQuery();

            if (con.rs.next()) {

                jSpinner1.setValue(con.rs.getInt("dp.cantidad"));
                jDateChooser1.setDate(con.rs.getDate("pdc.fecha"));
                umed.setSelectedItem(con.rs.getString("prod.unidad_medida"));
                jComboBox2.setSelectedIndex(con.rs.getInt("id_producto"));
                jComboBox5.setSelectedIndex(con.rs.getInt("id_cliente"));
            } else {
                JOptionPane.showMessageDialog(null, "No existe un producto del pedido con ese nombre");
            }

        } catch (Exception e) {
            System.err.println(e);
        }
        con.closeConexion();
    }//GEN-LAST:event_rSButtonMetro5ActionPerformed

    private void umedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_umedActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_umedActionPerformed

    private void jComboBox9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox9ActionPerformed

    private void rSButtonMetro6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro6ActionPerformed
        // TODO add your handling code here:
        Conexion con = new Conexion();
        Connection conn = con.getConexion();
        con.getConexion();
        Date fecha = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fechaactual = sdf.format(fecha);

        int fila = tablaPedClie.getSelectedRow();

        int valor = parseInt(tablaPedClie.getValueAt(fila, 0).toString());

        if (fila >= 0) {

            try {

                con.ps = conn.prepareStatement("UPDATE pedido_cliente SET statusbajapedcl=? WHERE id_pedido_cliente=" + valor);

                con.ps.setString(1, fechaactual);

                int res = con.ps.executeUpdate();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "El pedido no se ha podido dar de baja");
            }
            try {

                con.ps = conn.prepareStatement("UPDATE detalle_pedido SET statusbajadtp=? WHERE id_pedido_cliente=" + valor);

                con.ps.setString(1, fechaactual);

                int res = con.ps.executeUpdate();
                if (res > 0) {
                    JOptionPane.showMessageDialog(null, "pedido dado de baja");
                    cargarpedido("");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "El pedido no se ha podido dar de baja");
            }

        }
        con.closeConexion();


    }//GEN-LAST:event_rSButtonMetro6ActionPerformed

    private void rSButtonMetro8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro8ActionPerformed
        // TODO add your handling code here:
        PantallaClientes cl = new PantallaClientes();
        cl.setVisible(true);

    }//GEN-LAST:event_rSButtonMetro8ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void MPbotonMateriaPrima9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima9ActionPerformed
        // TODO add your handling code here:
        PantallaPedidos pd = new PantallaPedidos();
        pd.setVisible(false);

        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);
    }//GEN-LAST:event_MPbotonMateriaPrima9ActionPerformed

    private void generarpedido1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generarpedido1ActionPerformed
        // TODO add your handling code here:
        Conexion con = new Conexion();
        Connection conn = con.getConexion();
        con.getConexion();
        int idprov = (int) jComboBox14.getSelectedIndex();

        Date fecha = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fechaactual = sdf.format(fecha);
        try {
            Thread.sleep(2000);
            con.ps = conn.prepareStatement("INSERT INTO pedido_a_proveedor(fecha,id_proveedor) VALUES (?,?)");

            con.ps.setString(1, fechaactual);
            con.ps.setInt(2, idprov);

            int res = con.ps.executeUpdate();

            if (res > 0) {
                JOptionPane.showMessageDialog(null, "DESCRIPCION PROVEEDOR  SE GUARDO CORRECTAMENTE.");
                cargarprovped();
                cargar("");
                resercombobox();
                
con.closeConexion();
            } else {
                JOptionPane.showMessageDialog(null, "DESCRIPCION DEL PEDIDO PROVEEDOR NO SE HA GUARDADO CORRECTAMENTE");
            }

        } catch (Exception e) {
            System.err.println(e);
        }

        con.getConexion();
    }//GEN-LAST:event_generarpedido1ActionPerformed

    private void generarpedido3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generarpedido3ActionPerformed
        // TODO add your handling code here:

        Conexion con = new Conexion();
        Connection conn = con.getConexion();
        try {
            con.getConexion();
            Thread.sleep(2000);
            int cantidad = (int) jSpinner2.getValue();

            

            int selectmp = (int) jComboBox7.getSelectedIndex();

            con.ps = conn.prepareStatement("INSERT INTO detalle_pedido_proveedor(cantidad,id_materia_prima,id_pedido_proveedor) VALUES (?,?,?)");

            con.ps.setInt(1, cantidad);
            con.ps.setInt(2, selectmp);
           

            int res = con.ps.executeUpdate();
con.closeConexion();
        } catch (Exception e) {
            System.err.println(e);
        }

con.getConexion();
        try {

            int cantidad = (int) jSpinner2.getValue();
            int selectmp = (int) jComboBox7.getSelectedIndex();

            con.ps = conn.prepareStatement("UPDATE materia_prima a, detalle_pedido_proveedor b SET a.stock = b.cantidad+a.stock WHERE a.id_materia_prima = b.id_materia_prima");

            int res = con.ps.executeUpdate();

            if (res > 0) {
                JOptionPane.showMessageDialog(null, "DETALLE DEl PEDIDO PROVEEDOR  SE GUARDO CORRECTAMENTE.");
                resercombobox();
                cargardetalleproveedor("");

            } else {
                JOptionPane.showMessageDialog(null, "LOS DETOS DEL PEDIDO PROVEEDOR NO SE HA GUARDADO CORRECTAMENTE");
            }
        } catch (Exception e) {
            System.err.println(e);
        }
        con.closeConexion();
       
    }//GEN-LAST:event_generarpedido3ActionPerformed

    private void jComboBox11ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox11ItemStateChanged
        // TODO add your handling code here:
        Conexion con = new Conexion();
        Connection conn = con.getConexion();
        con.getConexion();

        int Filtros = (int) jComboBox11.getSelectedIndex();

        String detalleProv[] = new String[2];
        String[] titulos4 = {"Ingrediente ", "Cantidad",};
        con.model = new DefaultTableModel(null, titulos4);
        try {

            String SQL = "SELECT id_detalle_pedido_proveedor,descripcion,cantidad FROM detalle_pedido_proveedor AS dpp JOIN materia_prima mp ON dpp.id_materia_prima=mp.id_materia_prima  where statusbajadtpedprov is null and id_pedido_proveedor=" + Filtros;
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                detalleProv[0] = rs.getString("descripcion");
                detalleProv[1] = rs.getString("cantidad");

                con.model.addRow(detalleProv);
                jTable2.setModel(con.model);

                jComboBox9.addItem(rs.getString("descripcion"));

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }


    }//GEN-LAST:event_jComboBox11ItemStateChanged

    private void generarpedido1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_generarpedido1MouseClicked
        // TODO add your handling code here:

        cargar("");
        nuevoPedidoProveedor.setVisible(false);
        nuevoPedidoProveedor.setVisible(true);
        nuevoPedidoProveedor.setSize(890, 590);
        nuevoPedidoProveedor.setResizable(false);
        nuevoPedidoProveedor.setLocationRelativeTo(null);
    }//GEN-LAST:event_generarpedido1MouseClicked

    private void generarpedido3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_generarpedido3MouseClicked
        // TODO add your handling code here:

        cargardetalleproveedor("");

        nuevoPedidoProveedor.setVisible(false);
        nuevoPedidoProveedor.setVisible(true);
        nuevoPedidoProveedor.setSize(890, 590);
        nuevoPedidoProveedor.setResizable(false);
        nuevoPedidoProveedor.setLocationRelativeTo(null);
    }//GEN-LAST:event_generarpedido3MouseClicked

    private void jComboBox4ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox4ItemStateChanged
        // TODO add your handling code here:

    }//GEN-LAST:event_jComboBox4ItemStateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                try {
                    new PantallaPedidos().setVisible(true);

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e.getMessage());

                }

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima10;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima11;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima12;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima3;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima4;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima6;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima7;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima8;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima9;
    private javax.swing.JFrame ModificarPedCLiente;
    private javax.swing.JFrame NuevoPedClie;
    private javax.swing.JFrame PantallaClientes;
    private rsbuttom.RSButtonMetro botonPedidosProveedor;
    private rsbuttom.RSButtonMetro generarpedido1;
    private rsbuttom.RSButtonMetro generarpedido3;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox11;
    private javax.swing.JComboBox<String> jComboBox14;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JComboBox<String> jComboBox9;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator12;
    private javax.swing.JSeparator jSeparator13;
    private javax.swing.JSeparator jSeparator14;
    private javax.swing.JSeparator jSeparator15;
    private javax.swing.JSeparator jSeparator18;
    private javax.swing.JSeparator jSeparator19;
    private javax.swing.JSeparator jSeparator23;
    private javax.swing.JSeparator jSeparator26;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private com.toedter.components.JSpinField jSpinField3;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JSpinner jSpinner2;
    private javax.swing.JSpinner jSpinner3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JFrame modificarPedido;
    private rsbuttom.RSButtonMetro modifrpedcliente2;
    private javax.swing.JFrame nuevoPedidoProveedor;
    private javax.swing.JFrame pantallaProveedor;
    private rsbuttom.RSButtonMetro rSButtonMetro1;
    private rsbuttom.RSButtonMetro rSButtonMetro2;
    private rsbuttom.RSButtonMetro rSButtonMetro3;
    private rsbuttom.RSButtonMetro rSButtonMetro4;
    private rsbuttom.RSButtonMetro rSButtonMetro5;
    private rsbuttom.RSButtonMetro rSButtonMetro6;
    private rsbuttom.RSButtonMetro rSButtonMetro8;
    private javax.swing.JComboBox<String> selectprod;
    private javax.swing.JTable tablaPedClie;
    private javax.swing.JTable table1;
    private javax.swing.JComboBox<String> umed;
    private javax.swing.JComboBox<String> unimedmod;
    // End of variables declaration//GEN-END:variables
}
