package SistemaPanificadora;

import java.awt.Dimension;
import java.awt.Toolkit;
import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Santi
 */
public class PantallaPedidos extends javax.swing.JFrame {

    private Object nombre;

    /**
     * Creates new form PantallaPedidos
     */
    public PantallaPedidos() {
        SpinnerNumberModel nm = new SpinnerNumberModel();

        initComponents();
        AutoCompleteDecorator.decorate(this.selectprod);
        AutoCompleteDecorator.decorate(this.jComboBox6);
        AutoCompleteDecorator.decorate(this.jComboBox7);
        AutoCompleteDecorator.decorate(this.jComboBox4);
        AutoCompleteDecorator.decorate(this.jComboBox5);
        AutoCompleteDecorator.decorate(this.jComboBox4);
        AutoCompleteDecorator.decorate(this.jComboBox8);
        
        AutoCompleteDecorator.decorate(this.jComboBox2);

        AutoCompleteDecorator.decorate(this.jComboBox14);

        AutoCompleteDecorator.decorate(this.jComboBox14);

        Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();

        this.setLocationRelativeTo(null);
        bloqueobotonelimienar();
        cargarprovped();
        cargarproducto();
       bloquearbtn();
        cargar("");
       // cargardetalleproveedor("");

    ocultartablapdc();   
        
        cargarproveedor();
        cargarmp();
        bloqueoopcionesdtr();

    }
    
    void bloquearbtn(){
        generarpedido1.setEnabled(false);
        generarpedido3.setEnabled(false);
        jButton7.setEnabled(false);
        jCheckBox2.setEnabled(false);
        rSButtonMetro2.setEnabled(false);
    }
   void activarbtngenerarcltbl(){
        jCheckBox2.setEnabled(true);
        jButton7.setEnabled(true);
    }
  void activarbtngenerarcl(){
       rSButtonMetro2.setEnabled(true);
   }
     void activarbtngenerar(){
         generarpedido1.setEnabled(true);
     } 
    void deshabilitarmodificarpedprov(){
        jComboBox5.setVisible(false);
        jSpinner3.setVisible(false);
    }
    void habilitarmodificarpedprov(){
        jComboBox5.setVisible(true);
        jSpinner3.setVisible(true);
    }
    void deshabilitartablapedprov(){
        jComboBox7.setEnabled(false);
        jSpinner2.setEnabled(false);
        jCheckBox1.setEnabled(false);
        generarpedido3.setEnabled(false);
       jTextField2.setEnabled(false);
        
    }
    void habilitartablapedprov(){
        jComboBox7.setEnabled(true);
        jSpinner2.setEnabled(true);
        jCheckBox1.setEnabled(true);
        generarpedido3.setEnabled(true);
       jTextField2.setEnabled(true);
        
    }
    void ocultartablapdc(){
        tablaPedClie.setVisible(false);
    }
    void habilitartablapdc(){
        tablaPedClie.setVisible(true);
    }
    void bloqueoopcionesdtr(){
        jComboBox8.setEnabled(false);
        jCheckBox3.setEnabled(false);
        jSpinField3.setEnabled(false);
        jTextField1.setEnabled(false);
        rSButtonMetro7.setEnabled(false);
    }
    void activaropcionesdtr(){
        jComboBox8.setEnabled(true);
        jCheckBox3.setEnabled(true);
        jSpinField3.setEnabled(true);
        jTextField1.setEnabled(true);
        rSButtonMetro7.setEnabled(true);
    }
    void bloqueobotonelimienar(){
        rSButtonMetro6.setEnabled(false);
    }
    void activarbotonelimienar(){
        rSButtonMetro6.setEnabled(true);
    }
   void bloqueoordprod(){
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
        int fila = jTable5.getSelectedRow();

        int valor = parseInt(jTable5.getValueAt(fila, 0).toString());
        try {
            con.getConexion();
            String SQL = "SELECT * FROM detalle_pedido AS dp JOIN producto p ON dp.id_producto=p.id_producto JOIN pedido_cliente pc ON dp.id_pedido_cliente=pc.id_pedido_cliente where statusbajadt is null and pc.id_pedido_cliente=" + valor;
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            int resultado = 0;
            while (rs.next()) {

                resultado = rs.getInt("interno");
                System.out.println(resultado);
                if (resultado == 0) {
                    jCheckBox1.setSelected(true);
                    
                } else {
                    jCheckBox1.setSelected(false);
          
                }

            }}catch(Exception e){
                
            }

   }

    void bloqueopaneldtr() {
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();

        String check[] = new String[1];
        String[] titulos2 = {""};
        con.model = new DefaultTableModel(null, titulos2);

        int fila = jTable1.getSelectedRow();

        int valor = parseInt(jTable1.getValueAt(fila, 0).toString());
        try {
            con.getConexion();
            String SQL = "SELECT control FROM pedido_a_proveedor WHERE  statusbajapedprov is null AND id_pedido_proveedor=" + valor;
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            int resultado = 0;
            while (rs.next()) {

                resultado = rs.getInt("control");

                if (resultado == 1) {
                    jCheckBox1.setSelected(true);
                    jComboBox7.setEnabled(false);
                    jSpinner2.setEnabled(false);
                    generarpedido3.setEnabled(false);
                    generarpedido3.setVisible(false);
                } else {
                    jCheckBox1.setSelected(false);
                    jComboBox7.setEnabled(true);
                    jSpinner2.setEnabled(true);
                    generarpedido3.setEnabled(true);
                    generarpedido3.setVisible(true);
                }

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();

    }

    void bloqueopanelpdc() {
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
        String resultado = "";
        String comp = "Entregado";
        String check[] = new String[1];
        String[] titulos2 = {""};
        con.model = new DefaultTableModel(null, titulos2);

        int fila = jTable4.getSelectedRow();

        int valor = parseInt(jTable4.getValueAt(fila, 0).toString());
        try {
            con.getConexion();
            String SQL = "SELECT * FROM pedido_cliente WHERE  statusbajapedcl is null AND id_pedido_cliente=" + valor;
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {

                resultado = rs.getString("estado") + resultado;

                if (resultado.equals(comp)) {
                    jCheckBox2.setSelected(true);
                    jSpinField3.setEnabled(false);
                    jComboBox8.setEnabled(false);
                    rSButtonMetro7.setEnabled(false);
                    jCheckBox3.setEnabled(false);
                } else {
                    jCheckBox2.setSelected(false);
                    jSpinField3.setEnabled(true);
                    jComboBox8.setEnabled(true);
                    rSButtonMetro7.setEnabled(true);
                    jCheckBox3.setEnabled(true);
                }

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();

    }

    void modificarpedprov() {
        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        int filtropedprov = (int) jComboBox4.getSelectedIndex();
        String[] titulos = {"Codigo", "ingrediente", "cantidad"};
        c.model = new DefaultTableModel(null, titulos);
        String filtropedpro[] = new String[3];
        c.getConexion();
        try {

            String SQL = "SELECT *FROM detalle_pedido_proveedor AS dpp JOIN materia_prima mp ON dpp.id_materia_prima= mp.id_materia_prima where statusbajadtpedprov is null and id_pedido_proveedor=" + filtropedprov;
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                filtropedpro[0] = rs.getString("id_detalle_pedido_proveedor");
                filtropedpro[1] = rs.getString("descripcion");
                filtropedpro[2] = rs.getString("cantidad");

                c.model.addRow(filtropedpro);
                jTable7.setModel(c.model);

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        c.closeConexion();
    }

    void modificadtr() {
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
     int filtro = (int) jComboBox6.getSelectedIndex();
        System.out.println(filtro);
        String[] titulos = {"Codigo", "Producto", "Cantidad"};
        con.model = new DefaultTableModel(null, titulos);
        String filtrar[] = new String[3];
        con.getConexion();
        try {

            String SQL = "SELECT  id_pedido_cliente,id_detalle_pedido,descripcion,cantidad,statusbajadt FROM detalle_pedido AS dp JOIN producto p ON dp.id_producto=p.id_producto where statusbajadt is null and id_pedido_cliente="+filtro;
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                filtrar[0] = rs.getString("id_detalle_pedido");
                filtrar[1] = rs.getString("descripcion");
                filtrar[2] = rs.getString("cantidad");

                con.model.addRow(filtrar);
                jTable6.setModel(con.model);

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }

    void resercombobox() {
        selectprod.setSelectedIndex(0);
        jComboBox6.setSelectedIndex(0);
        jComboBox7.setSelectedIndex(0);
        jComboBox4.setSelectedIndex(0);
        jComboBox5.setSelectedIndex(0);
jTable3.setVisible(false);
        jComboBox14.setSelectedIndex(0);

        jSpinner2.setValue(0);

    }

    void cargarprovped() {
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();

        String mp[] = new String[8];
        String[] titulos2 = {""};
        con.model = new DefaultTableModel(null, titulos2);
        try {
            con.getConexion();
            String SQL = "SELECT * FROM pedido_a_proveedor WHERE  statusbajapedprov is null";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();

    }

    void cargadescripciondtr() {

        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();

        String mp[] = new String[8];
        String[] titulos2 = {""};
        con.model = new DefaultTableModel(null, titulos2);
        try {
            con.getConexion();
            String SQL = "select descripcion FROM pedido_cliente AS pdc JOIN detalle_pedido dtp ON pdc.id_pedido_cliente=dtp.id_pedido_cliente JOIN producto p ON dtp.id_producto=p.id_producto JOIN cliente cl ON pdc.id_cliente= cl.id_cliente where   statusbajapedcl is null ";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                jComboBox2.addItem(rs.getString("descripcion"));
             
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }
    void cargacodigodtr() {

        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();

        String mp[] = new String[8];
        String[] titulos2 = {""};
        con.model = new DefaultTableModel(null, titulos2);
        try {
            con.getConexion();
            String SQL = "select DISTINCT pdc.id_pedido_cliente FROM pedido_cliente AS pdc JOIN detalle_pedido dtp ON pdc.id_pedido_cliente=dtp.id_pedido_cliente JOIN producto p ON dtp.id_producto=p.id_producto JOIN cliente cl ON pdc.id_cliente= cl.id_cliente where   statusbajapedcl is null";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                
                jComboBox6.addItem(rs.getString("id_pedido_cliente"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }

    void cargarmp() {
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();

        String mp[] = new String[8];
        String[] titulos2 = {""};
        con.model = new DefaultTableModel(null, titulos2);
        try {
            con.getConexion();
            String SQL = "SELECT * FROM `materia_prima` WHERE  statusbajamp is null";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                jComboBox7.addItem(rs.getString("descripcion"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }

    void cargarpedido(String Valor) {
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
        con.getConexion();
        //carga de detalle pedido al cliente
 String filtro = jTextField3.getText();
        String Pedidos[] = new String[7];

        String[] titulos = {"Codigo", "Cliente", "Producto", "Cantidad", "Unidad Medida", "Estado", "Fecha"};
        con.model = new DefaultTableModel(null, titulos);
        try {

            String SQL = "select pdc.id_pedido_cliente,cantidad,statusbajadt,estado,fecha,statusbajapedcl,nombre,statusbajacl,descripcion,unidad_medida FROM pedido_cliente AS pdc JOIN detalle_pedido dtp ON pdc.id_pedido_cliente=dtp.id_pedido_cliente JOIN producto p ON dtp.id_producto=p.id_producto JOIN cliente cl ON pdc.id_cliente= cl.id_cliente where pdc.id_pedido_cliente LIKE '%" + Valor + "%'  AND statusbajapedcl is null AND pdc.id_pedido_cliente LIKE '%" + filtro + "%' ORDER BY nombre";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                Pedidos[0] = rs.getString("pdc.id_pedido_cliente");
                Pedidos[1] = rs.getString("nombre");
                Pedidos[2] = rs.getString("descripcion");
                Pedidos[3] = rs.getString("cantidad");
                Pedidos[4] = rs.getString("unidad_medida");
                Pedidos[5] = rs.getString("pdc.estado");
                Pedidos[6] = rs.getString("pdc.fecha");

                con.model.addRow(Pedidos);

               
                tablaPedClie.setModel(con.model);

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }
    //cargar detalle pedido

//Carga BBDD Pedido Proveedor/*/*/*/*/*//*/*/*/*/*/*/
    void cargar(String provalor) {
        //proveedores

        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();

        String pedidosProv[] = new String[4];
        String[] titulos2 = {"Cod pedido proveedor", "Proveedor", "Fecha",};
        con.model = new DefaultTableModel(null, titulos2);
        try {
            con.getConexion();
            String SQL = "select id_pedido_proveedor,nombre,fecha,pprov.id_proveedor,control from pedido_a_proveedor AS pprov JOIN proveedor p ON pprov.id_proveedor = p.id_proveedor where id_pedido_proveedor LIKE '%" + provalor + "%' and statusbajapedprov is null ";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                pedidosProv[0] = rs.getString("id_pedido_proveedor");
                pedidosProv[1] = rs.getString("nombre");
                pedidosProv[2] = rs.getString("fecha");
                pedidosProv[3] = rs.getString("control");

                jComboBox4.addItem(rs.getString("id_pedido_proveedor"));

                

                con.model.addRow(pedidosProv);
                jTable1.setModel(con.model);
                con.getConexion();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }
//carga detalle pedido proveedor

    void cargardetalleproveedor(String cdtp) {
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();

        String detalleProv[] = new String[4];
        String[] titulos4 = {"Cod detalle pedido proveedor", "Ingrediente ", "Cantidad","unidad_media"};
        con.model = new DefaultTableModel(null, titulos4);
        try {
            con.getConexion();
            String SQL = "SELECT  id_detalle_pedido_proveedor,descripcion,cantidad,id_pedido_proveedor,unidad_medida FROM detalle_pedido_proveedor AS dpp JOIN materia_prima mp ON dpp.id_materia_prima=mp.id_materia_prima where id_detalle_pedido_proveedor LIKE '%" + cdtp + "%' and statusbajadtpedprov is null";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                detalleProv[0] = rs.getString("id_detalle_pedido_proveedor");
                detalleProv[1] = rs.getString("descripcion");
                detalleProv[2] = rs.getString("cantidad");
                detalleProv[3] = rs.getString("unidad_medida");

                con.model.addRow(detalleProv);
                jTable3.setModel(con.model);

                con.getConexion();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }
//carga los datos del producto

    void cargarproducto() {
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();

        try {
            con.getConexion();
            String SQL = "SELECT * from producto where statusbajaProd is null ";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                selectprod.addItem(rs.getString("descripcion"));
                jComboBox8.addItem(rs.getString("descripcion"));

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }

    void cargarcliente() {

        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
        try {
            con.getConexion();
            String SQL = "SELECT *from cliente where statusbajacl is null ";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                jComboBox3.addItem(rs.getString("nombre"));

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }

    void cargarproveedor() {
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();

        try {

            con.getConexion();
            String SQL = "SELECT *from proveedor  ";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                jComboBox14.addItem(rs.getString("nombre"));

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }
//cargar pedidocl

    void pedidocl(String pdc) {
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
        con.getConexion();
        //carga de detalle pedido al cliente

        String Pedidos[] = new String[4];

        String[] titulos = {"Codigo", "Cliente", "Estado", "Fecha"};
        con.model = new DefaultTableModel(null, titulos);
        try {

            String SQL = "SELECT  id_pedido_cliente,nombre, estado,fecha,statusbajapedcl FROM pedido_cliente AS pdc JOIN cliente cl ON pdc.id_cliente=cl.id_cliente where id_pedido_cliente LIKE '%" + pdc + "%'  AND statusbajapedcl is null";

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                Pedidos[0] = rs.getString("id_pedido_cliente");
                Pedidos[1] = rs.getString("nombre");
                Pedidos[2] = rs.getString("estado");
                Pedidos[3] = rs.getString("fecha");
                
                con.model.addRow(Pedidos);

                jTable4.setModel(con.model);

                con.getConexion();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }

    void lecturaegramos() {
        float Cantidades = 0;
        String Medida = "";
        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        int fila = jTable4.getSelectedRow();
        int filtroa = parseInt(jTable4.getValueAt(fila, 0).toString());
        String Pedidos[] = new String[3];
        float resultado = 0;
        c.getConexion();
        try {

            c.ps = conn.prepareStatement("SELECT `id_detalle_pedido`,`id_pedido_cliente`,`descripcion`,`cantidad`,`statusbajadt`,`unidad_medida` FROM detalle_pedido AS dp JOIN producto p ON dp.id_producto=p.id_producto where  statusbajadt is null AND id_pedido_cliente=" + filtroa);

            c.rs = c.ps.executeQuery();

            while (c.rs.next()) {

                Cantidades = (c.rs.getFloat("cantidad"));
                Medida = (c.rs.getString("unidad_medida"));

                if (Cantidades < 1.00) {
                 Pedidos[2]= Medida = "Gr";

                } else {
                  Pedidos[2]= Medida = "Kg";
                }
                Pedidos[0] = c.rs.getString("descripcion");
                Pedidos[1] = c.rs.getString("cantidad");
                Pedidos[2] = c.rs.getString(Medida);
          
                jTable5.setModel(c.model);
            }

        } catch (Exception e) {
            e.printStackTrace();
// System.err.println(e);
        }
        c.closeConexion();
    }

//carga detallepdc
    public void detallepdc(String dtpdc) {
        int fila = jTable4.getSelectedRow();
        int filtroa = parseInt(jTable4.getValueAt(fila, 0).toString());

        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
        con.getConexion();
        //carga de detalle pedido al cliente

        String Pedidos[] = new String[5];

        String[] titulos = {"Codigo","Producto", "Cantidad solicitada", "Unidad de medida"};
        con.model = new DefaultTableModel(null, titulos);
        try {

            String SQL = "SELECT `id_detalle_pedido`,`id_pedido_cliente`,`descripcion`,`cantidad`,`statusbajadt`,`unidad_medida` FROM detalle_pedido AS dp JOIN producto p ON dp.id_producto=p.id_producto where id_detalle_pedido LIKE '%" + dtpdc + "%'  AND statusbajadt is null AND id_pedido_cliente=" + filtroa;

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                Pedidos[0] = rs.getString("id_detalle_pedido");
                Pedidos[1] = rs.getString("descripcion");
                Pedidos[2] = rs.getString("cantidad");
                Pedidos[3] = rs.getString("unidad_medida");
                

                con.model.addRow(Pedidos);

                jTable5.setModel(con.model);

                con.getConexion();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pantallaProveedor = new javax.swing.JFrame();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel12 = new javax.swing.JPanel();
        MPbotonMateriaPrima4 = new rsbuttom.RSButtonMetro();
        MPbotonMateriaPrima3 = new rsbuttom.RSButtonMetro();
        MPbotonMateriaPrima6 = new rsbuttom.RSButtonMetro();
        jComboBox11 = new javax.swing.JComboBox<>();
        nuevoPedidoProveedor = new javax.swing.JFrame();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jComboBox7 = new javax.swing.JComboBox<>();
        jSpinner2 = new javax.swing.JSpinner();
        generarpedido3 = new rsbuttom.RSButtonMetro();
        jCheckBox1 = new javax.swing.JCheckBox();
        jTextField2 = new javax.swing.JTextField();
        jPanel18 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jComboBox14 = new javax.swing.JComboBox<>();
        generarpedido1 = new rsbuttom.RSButtonMetro();
        MPbotonMateriaPrima9 = new rsbuttom.RSButtonMetro();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        modificarPedido = new javax.swing.JFrame();
        jPanel6 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        MPbotonMateriaPrima7 = new rsbuttom.RSButtonMetro();
        MPbotonMateriaPrima8 = new rsbuttom.RSButtonMetro();
        jSeparator5 = new javax.swing.JSeparator();
        jComboBox4 = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTable7 = new javax.swing.JTable();
        jSeparator6 = new javax.swing.JSeparator();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jComboBox5 = new javax.swing.JComboBox<>();
        jSpinner3 = new javax.swing.JSpinner();
        jButton6 = new javax.swing.JButton();
        ModificarPedCLiente = new javax.swing.JFrame();
        jPanel10 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jButton9 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jSeparator15 = new javax.swing.JSeparator();
        jSeparator23 = new javax.swing.JSeparator();
        jComboBox6 = new javax.swing.JComboBox<>();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable6 = new javax.swing.JTable();
        jComboBox2 = new javax.swing.JComboBox<>();
        jSpinner1 = new javax.swing.JSpinner();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        MPbotonMateriaPrima11 = new rsbuttom.RSButtonMetro();
        modifrpedcliente2 = new rsbuttom.RSButtonMetro();
        NuevoPedClie = new javax.swing.JFrame();
        jPanel23 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jSeparator19 = new javax.swing.JSeparator();
        jComboBox3 = new javax.swing.JComboBox<>();
        rSButtonMetro2 = new rsbuttom.RSButtonMetro();
        jLabel37 = new javax.swing.JLabel();
        jCheckBox2 = new javax.swing.JCheckBox();
        jButton7 = new javax.swing.JButton();
        MPbotonMateriaPrima10 = new rsbuttom.RSButtonMetro();
        rSButtonMetro8 = new rsbuttom.RSButtonMetro();
        jPanel17 = new javax.swing.JPanel();
        jSpinField3 = new com.toedter.components.JSpinField();
        selectprod = new javax.swing.JComboBox<>();
        jSeparator26 = new javax.swing.JSeparator();
        jLabel28 = new javax.swing.JLabel();
        jComboBox8 = new javax.swing.JComboBox<>();
        rSButtonMetro7 = new rsbuttom.RSButtonMetro();
        jTextField1 = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jSeparator20 = new javax.swing.JSeparator();
        jCheckBox3 = new javax.swing.JCheckBox();
        jLabel30 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        jPanel11 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        PantallaClientes = new javax.swing.JFrame();
        jPanel25 = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        jButton11 = new javax.swing.JButton();
        jLabel31 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tablaPedClie = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        rSButtonMetro3 = new rsbuttom.RSButtonMetro();
        rSButtonMetro4 = new rsbuttom.RSButtonMetro();
        rSButtonMetro6 = new rsbuttom.RSButtonMetro();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel13 = new javax.swing.JPanel();
        MPbotonMateriaPrima12 = new rsbuttom.RSButtonMetro();
        rSButtonMetro1 = new rsbuttom.RSButtonMetro();
        botonPedidosProveedor = new rsbuttom.RSButtonMetro();

        pantallaProveedor.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(230, 205, 141));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel4.setFont(new java.awt.Font("Roboto Thin", 1, 36)); // NOI18N
        jLabel4.setText("Pedidos Proveedor");

        jButton2.setBackground(new java.awt.Color(230, 205, 141));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(228, 228, 228)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(251, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pantallaProveedor.getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 80));

        jPanel5.setBackground(new java.awt.Color(244, 243, 239));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jPanel5.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 780, 200));

        jPanel12.setBackground(new java.awt.Color(244, 243, 239));
        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto Thin", 1, 14))); // NOI18N

        MPbotonMateriaPrima4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar_1.png"))); // NOI18N
        MPbotonMateriaPrima4.setText("Modificar Pedido");
        MPbotonMateriaPrima4.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima4.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima4.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima4.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima4.setColorTextPressed(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima4.setDefaultCapable(false);
        MPbotonMateriaPrima4.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        MPbotonMateriaPrima4.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima4.setIconTextGap(25);
        MPbotonMateriaPrima4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima4ActionPerformed(evt);
            }
        });

        MPbotonMateriaPrima3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Ordenproduccion.png"))); // NOI18N
        MPbotonMateriaPrima3.setText("Generar Pedido");
        MPbotonMateriaPrima3.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima3.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima3.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima3.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima3.setColorTextPressed(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima3.setDefaultCapable(false);
        MPbotonMateriaPrima3.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        MPbotonMateriaPrima3.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima3.setIconTextGap(25);
        MPbotonMateriaPrima3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima3ActionPerformed(evt);
            }
        });

        MPbotonMateriaPrima6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima6.setText("Volver Al Home");
        MPbotonMateriaPrima6.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima6.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima6.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima6.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima6.setColorTextPressed(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima6.setDefaultCapable(false);
        MPbotonMateriaPrima6.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        MPbotonMateriaPrima6.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima6.setIconTextGap(25);
        MPbotonMateriaPrima6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MPbotonMateriaPrima3, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(MPbotonMateriaPrima6, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(MPbotonMateriaPrima4, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MPbotonMateriaPrima3, javax.swing.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE)
                    .addComponent(MPbotonMateriaPrima6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(MPbotonMateriaPrima4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel5.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, 730, 110));

        jComboBox11.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jComboBox11.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox11ItemStateChanged(evt);
            }
        });
        jComboBox11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComboBox11MouseClicked(evt);
            }
        });
        jPanel5.add(jComboBox11, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 10, 150, -1));

        pantallaProveedor.getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 870, 420));

        nuevoPedidoProveedor.setMaximumSize(new java.awt.Dimension(1007, 568));
        nuevoPedidoProveedor.setMinimumSize(new java.awt.Dimension(1007, 568));

        jPanel7.setBackground(new java.awt.Color(244, 243, 239));
        jPanel7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel7.setLayout(null);

        jPanel8.setBackground(new java.awt.Color(230, 205, 141));
        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButton3.setBackground(new java.awt.Color(230, 205, 141));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Roboto Thin", 1, 24)); // NOI18N
        jLabel5.setText("Generar Descripcion Pedido Proveedor");

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 157, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(138, 138, 138)
                .addComponent(jLabel5)
                .addContainerGap(372, Short.MAX_VALUE))
            .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.add(jPanel8);
        jPanel8.setBounds(0, 0, 1010, 70);

        jPanel14.setBackground(new java.awt.Color(244, 243, 239));
        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Detalle del pedido a proveedor", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Roboto Thin", 1, 14))); // NOI18N
        jPanel14.setLayout(null);

        jLabel6.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel6.setText("Seleccionar ingrediente");
        jPanel14.add(jLabel6);
        jLabel6.setBounds(10, 30, 160, 30);

        jLabel16.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel16.setText("Ingrese la cantidad:");
        jPanel14.add(jLabel16);
        jLabel16.setBounds(20, 90, 170, 30);
        jPanel14.add(jSeparator3);
        jSeparator3.setBounds(0, 150, 450, 10);
        jPanel14.add(jSeparator4);
        jSeparator4.setBounds(0, 70, 420, 10);

        jComboBox7.setEditable(true);
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar o escribir" }));
        jComboBox7.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox7ItemStateChanged(evt);
            }
        });
        jComboBox7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComboBox7MouseClicked(evt);
            }
        });
        jPanel14.add(jComboBox7);
        jComboBox7.setBounds(180, 30, 160, 30);
        jPanel14.add(jSpinner2);
        jSpinner2.setBounds(180, 90, 160, 30);

        generarpedido3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        generarpedido3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar.png"))); // NOI18N
        generarpedido3.setText("Generar Detalle Pedido");
        generarpedido3.setColorHover(new java.awt.Color(230, 205, 141));
        generarpedido3.setColorNormal(new java.awt.Color(244, 243, 239));
        generarpedido3.setColorPressed(new java.awt.Color(244, 237, 210));
        generarpedido3.setColorTextNormal(new java.awt.Color(0, 0, 0));
        generarpedido3.setDefaultCapable(false);
        generarpedido3.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        generarpedido3.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        generarpedido3.setIconTextGap(25);
        generarpedido3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                generarpedido3MouseClicked(evt);
            }
        });
        generarpedido3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generarpedido3ActionPerformed(evt);
            }
        });
        jPanel14.add(generarpedido3);
        generarpedido3.setBounds(140, 200, 240, 50);

        jCheckBox1.setText("Verificado");
        jCheckBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCheckBox1ItemStateChanged(evt);
            }
        });
        jCheckBox1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCheckBox1MouseClicked(evt);
            }
        });
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });
        jPanel14.add(jCheckBox1);
        jCheckBox1.setBounds(200, 160, 79, 25);

        jTextField2.setEditable(false);
        jTextField2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jPanel14.add(jTextField2);
        jTextField2.setBounds(360, 90, 30, 30);

        jPanel7.add(jPanel14);
        jPanel14.setBounds(420, 230, 580, 270);

        jPanel18.setBackground(new java.awt.Color(244, 243, 239));
        jPanel18.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Nuevo Pedido a Proveedor", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Roboto Thin", 1, 14))); // NOI18N
        jPanel18.setLayout(null);

        jLabel15.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel15.setText("Proveedor");
        jPanel18.add(jLabel15);
        jLabel15.setBounds(20, 100, 170, 30);

        jComboBox14.setEditable(true);
        jComboBox14.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jComboBox14.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox14ItemStateChanged(evt);
            }
        });
        jPanel18.add(jComboBox14);
        jComboBox14.setBounds(190, 100, 160, 30);

        generarpedido1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        generarpedido1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar.png"))); // NOI18N
        generarpedido1.setText("Generar Pedido");
        generarpedido1.setColorHover(new java.awt.Color(230, 205, 141));
        generarpedido1.setColorNormal(new java.awt.Color(244, 243, 239));
        generarpedido1.setColorPressed(new java.awt.Color(244, 237, 210));
        generarpedido1.setColorTextNormal(new java.awt.Color(0, 0, 0));
        generarpedido1.setDefaultCapable(false);
        generarpedido1.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        generarpedido1.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        generarpedido1.setIconTextGap(25);
        generarpedido1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                generarpedido1MouseClicked(evt);
            }
        });
        generarpedido1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generarpedido1ActionPerformed(evt);
            }
        });
        jPanel18.add(generarpedido1);
        generarpedido1.setBounds(90, 210, 190, 50);

        jPanel7.add(jPanel18);
        jPanel18.setBounds(20, 230, 400, 280);

        MPbotonMateriaPrima9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MPbotonMateriaPrima9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima9.setText("Volver al Home");
        MPbotonMateriaPrima9.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima9.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima9.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima9.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima9.setDefaultCapable(false);
        MPbotonMateriaPrima9.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        MPbotonMateriaPrima9.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima9.setIconTextGap(25);
        MPbotonMateriaPrima9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima9ActionPerformed(evt);
            }
        });
        jPanel7.add(MPbotonMateriaPrima9);
        MPbotonMateriaPrima9.setBounds(330, 510, 190, 50);

        jTable1.setAutoCreateRowSorter(true);
        jTable1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable1.addHierarchyListener(new java.awt.event.HierarchyListener() {
            public void hierarchyChanged(java.awt.event.HierarchyEvent evt) {
                jTable1HierarchyChanged(evt);
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable1);

        jPanel7.add(jScrollPane3);
        jScrollPane3.setBounds(0, 70, 420, 160);

        jTable3.setAutoCreateRowSorter(true);
        jTable3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane5.setViewportView(jTable3);

        jPanel7.add(jScrollPane5);
        jScrollPane5.setBounds(420, 70, 580, 160);

        nuevoPedidoProveedor.getContentPane().add(jPanel7, java.awt.BorderLayout.CENTER);

        modificarPedido.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(244, 243, 239));
        jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel9.setBackground(new java.awt.Color(230, 205, 141));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButton4.setBackground(new java.awt.Color(230, 205, 141));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Roboto Thin", 1, 24)); // NOI18N
        jLabel14.setText("Modificar Pedido Proveedor");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(176, 176, 176)
                .addComponent(jLabel14)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel6.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 70));

        MPbotonMateriaPrima7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MPbotonMateriaPrima7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar_1.png"))); // NOI18N
        MPbotonMateriaPrima7.setText("Guardar Cambios");
        MPbotonMateriaPrima7.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima7.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima7.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima7.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima7.setDefaultCapable(false);
        MPbotonMateriaPrima7.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        MPbotonMateriaPrima7.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima7.setIconTextGap(10);
        MPbotonMateriaPrima7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima7ActionPerformed(evt);
            }
        });
        jPanel6.add(MPbotonMateriaPrima7, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 390, 193, 48));

        MPbotonMateriaPrima8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        MPbotonMateriaPrima8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima8.setText("Volver al Home");
        MPbotonMateriaPrima8.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima8.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima8.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima8.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima8.setDefaultCapable(false);
        MPbotonMateriaPrima8.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        MPbotonMateriaPrima8.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima8.setIconTextGap(25);
        MPbotonMateriaPrima8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima8ActionPerformed(evt);
            }
        });
        jPanel6.add(MPbotonMateriaPrima8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 390, 199, 48));
        jPanel6.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 380, 800, 10));

        jComboBox4.setEditable(true);
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Buscar" }));
        jComboBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox4ActionPerformed(evt);
            }
        });
        jPanel6.add(jComboBox4, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 80, 120, 20));

        jLabel8.setText("Codigo del pedido:");
        jPanel6.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 80, -1, -1));

        jTable7.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable7MouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(jTable7);

        jPanel6.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 120, 740, 180));
        jPanel6.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 800, 10));

        jLabel10.setText("Ingrediente:");
        jPanel6.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 330, -1, -1));

        jLabel11.setText("Cantidad:");
        jPanel6.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 330, -1, -1));

        jComboBox5.setEditable(true);
        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Buscar" }));
        jPanel6.add(jComboBox5, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 322, 120, 30));
        jPanel6.add(jSpinner3, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 320, 130, 30));

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Boton-buscar.png"))); // NOI18N
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 75, 40, 30));

        modificarPedido.getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 450));

        jPanel10.setBackground(new java.awt.Color(244, 243, 239));
        jPanel10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel10.setLayout(null);

        jPanel16.setBackground(new java.awt.Color(230, 205, 141));
        jPanel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButton9.setBackground(new java.awt.Color(230, 205, 141));
        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Roboto Thin", 1, 24)); // NOI18N
        jLabel19.setText("Modificar Pedido Cliente");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(128, 128, 128)
                .addComponent(jLabel19)
                .addContainerGap(209, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel19)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel10.add(jPanel16);
        jPanel16.setBounds(0, -3, 690, 80);

        jPanel19.setBackground(new java.awt.Color(244, 243, 239));
        jPanel19.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos Pedido:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto Light", 1, 14))); // NOI18N
        jPanel19.setLayout(null);

        jLabel21.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        jLabel21.setText("Cod pedido cliente");
        jPanel19.add(jLabel21);
        jLabel21.setBounds(80, 20, 180, 30);
        jPanel19.add(jSeparator15);
        jSeparator15.setBounds(20, 350, 630, 10);
        jPanel19.add(jSeparator23);
        jSeparator23.setBounds(20, 60, 630, 10);

        jComboBox6.setEditable(true);
        jComboBox6.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jComboBox6.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox6ItemStateChanged(evt);
            }
        });
        jComboBox6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComboBox6MouseClicked(evt);
            }
        });
        jPanel19.add(jComboBox6);
        jComboBox6.setBounds(380, 20, 150, 30);

        jTable6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable6MouseClicked(evt);
            }
        });
        jScrollPane8.setViewportView(jTable6);

        jPanel19.add(jScrollPane8);
        jScrollPane8.setBounds(10, 80, 630, 210);

        jComboBox2.setEditable(true);
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jPanel19.add(jComboBox2);
        jComboBox2.setBounds(110, 300, 140, 30);
        jPanel19.add(jSpinner1);
        jSpinner1.setBounds(430, 302, 180, 30);

        jLabel7.setText("Producto");
        jPanel19.add(jLabel7);
        jLabel7.setBounds(50, 306, 50, 20);

        jLabel9.setText("Cantidad");
        jPanel19.add(jLabel9);
        jLabel9.setBounds(370, 310, 50, 16);

        jPanel10.add(jPanel19);
        jPanel19.setBounds(10, 90, 660, 370);

        MPbotonMateriaPrima11.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima11.setText("Volver al Home");
        MPbotonMateriaPrima11.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima11.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima11.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima11.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima11.setDefaultCapable(false);
        MPbotonMateriaPrima11.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        MPbotonMateriaPrima11.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima11.setIconTextGap(25);
        MPbotonMateriaPrima11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima11ActionPerformed(evt);
            }
        });
        jPanel10.add(MPbotonMateriaPrima11);
        MPbotonMateriaPrima11.setBounds(20, 480, 199, 48);

        modifrpedcliente2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        modifrpedcliente2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar_1.png"))); // NOI18N
        modifrpedcliente2.setText("Modificar");
        modifrpedcliente2.setColorHover(new java.awt.Color(230, 205, 141));
        modifrpedcliente2.setColorNormal(new java.awt.Color(244, 243, 239));
        modifrpedcliente2.setColorPressed(new java.awt.Color(244, 237, 210));
        modifrpedcliente2.setColorTextNormal(new java.awt.Color(0, 0, 0));
        modifrpedcliente2.setColorTextPressed(new java.awt.Color(0, 0, 0));
        modifrpedcliente2.setDefaultCapable(false);
        modifrpedcliente2.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        modifrpedcliente2.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        modifrpedcliente2.setIconTextGap(25);
        modifrpedcliente2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifrpedcliente2ActionPerformed(evt);
            }
        });
        jPanel10.add(modifrpedcliente2);
        modifrpedcliente2.setBounds(440, 480, 227, 50);

        javax.swing.GroupLayout ModificarPedCLienteLayout = new javax.swing.GroupLayout(ModificarPedCLiente.getContentPane());
        ModificarPedCLiente.getContentPane().setLayout(ModificarPedCLienteLayout);
        ModificarPedCLienteLayout.setHorizontalGroup(
            ModificarPedCLienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, 691, Short.MAX_VALUE)
        );
        ModificarPedCLienteLayout.setVerticalGroup(
            ModificarPedCLienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, 550, Short.MAX_VALUE)
        );

        NuevoPedClie.setTitle("Nuevo Pedido Cliente");
        NuevoPedClie.setMinimumSize(new java.awt.Dimension(1030, 583));
        NuevoPedClie.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel23.setBackground(new java.awt.Color(244, 243, 239));
        jPanel23.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPanel24.setBackground(new java.awt.Color(244, 243, 239));
        jPanel24.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Ingrese el nuevo Pedido", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto Thin", 1, 14))); // NOI18N

        jComboBox3.setEditable(true);
        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Buscar" }));
        jComboBox3.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox3ItemStateChanged(evt);
            }
        });

        rSButtonMetro2.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/lista.png"))); // NOI18N
        rSButtonMetro2.setText("Generar Pedido");
        rSButtonMetro2.setColorBorde(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro2.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro2.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro2.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro2.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro2.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        rSButtonMetro2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro2ActionPerformed(evt);
            }
        });

        jLabel37.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel37.setText("Cliente:");

        jCheckBox2.setText("Marcar si el producto se encuentra entregado");
        jCheckBox2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCheckBox2MouseClicked(evt);
            }
        });

        jButton7.setText("Generar Orden Produccion");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addGap(125, 125, 125)
                .addComponent(rSButtonMetro2, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jSeparator19, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel24Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jCheckBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 44, Short.MAX_VALUE))
            .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel24Layout.createSequentialGroup()
                    .addGap(34, 34, 34)
                    .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(207, Short.MAX_VALUE)))
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(jSeparator19, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCheckBox2)
                .addGap(1, 1, 1)
                .addComponent(jButton7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rSButtonMetro2, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel24Layout.createSequentialGroup()
                    .addGap(31, 31, 31)
                    .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(154, Short.MAX_VALUE)))
        );

        MPbotonMateriaPrima10.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima10.setText("Volver al Home");
        MPbotonMateriaPrima10.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima10.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima10.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima10.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima10.setDefaultCapable(false);
        MPbotonMateriaPrima10.setFont(new java.awt.Font("Roboto Thin", 1, 14)); // NOI18N
        MPbotonMateriaPrima10.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima10.setIconTextGap(25);
        MPbotonMateriaPrima10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima10ActionPerformed(evt);
            }
        });

        rSButtonMetro8.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro8.setText("Nuevo Cliente");
        rSButtonMetro8.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro8.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro8.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro8.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro8ActionPerformed(evt);
            }
        });

        jPanel17.setBackground(new java.awt.Color(244, 243, 239));
        jPanel17.setBorder(javax.swing.BorderFactory.createTitledBorder("Detalle Pedido Cliente"));

        selectprod.setEditable(true);
        selectprod.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));

        jLabel28.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel28.setText("Cantidad");

        jComboBox8.setEditable(true);
        jComboBox8.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar" }));
        jComboBox8.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox8ItemStateChanged(evt);
            }
        });
        jComboBox8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComboBox8MouseClicked(evt);
            }
        });

        rSButtonMetro7.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro7.setForeground(new java.awt.Color(0, 0, 0));
        rSButtonMetro7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/lista.png"))); // NOI18N
        rSButtonMetro7.setText("Generar detalle pedido");
        rSButtonMetro7.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro7.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro7.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro7.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro7.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        rSButtonMetro7.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        rSButtonMetro7.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        rSButtonMetro7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro7ActionPerformed(evt);
            }
        });

        jTextField1.setEditable(false);
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel29.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel29.setText("Unidad Medida");

        jCheckBox3.setText("Unidad en GR");
        jCheckBox3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jCheckBox3MouseClicked(evt);
            }
        });
        jCheckBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox3ActionPerformed(evt);
            }
        });

        jLabel30.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel30.setText("Producto");

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSeparator26)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel17Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(selectprod, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel17Layout.createSequentialGroup()
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jComboBox8, 0, 140, Short.MAX_VALUE)
                            .addComponent(jLabel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jCheckBox3)
                        .addGap(8, 8, 8)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField1)
                            .addComponent(jLabel29, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jSpinField3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)))
                    .addComponent(jSeparator20))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(rSButtonMetro7, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(151, 151, 151))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSpinField3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jCheckBox3)))
                .addGap(4, 4, 4)
                .addComponent(jSeparator20, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rSButtonMetro7, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(343, 343, 343)
                .addComponent(selectprod, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(jSeparator26, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable4MouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(jTable4);

        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable5MouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(jTable5);

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 470, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(MPbotonMateriaPrima10, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(610, 610, 610)
                .addComponent(rSButtonMetro8, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel23Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel23Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(8, 8, 8)
                .addGroup(jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(MPbotonMateriaPrima10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rSButtonMetro8, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        NuevoPedClie.getContentPane().add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 82, 1020, 470));

        jPanel11.setBackground(new java.awt.Color(230, 205, 141));
        jPanel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel17.setFont(new java.awt.Font("Roboto Thin", 1, 24)); // NOI18N
        jLabel17.setText("Nuevo Pedido Cliente");

        jButton5.setBackground(new java.awt.Color(230, 205, 141));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(265, 265, 265)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        NuevoPedClie.getContentPane().add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1030, -1));

        PantallaClientes.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        PantallaClientes.setTitle("Gestion  pedidos cliente");
        PantallaClientes.getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel25.setBackground(new java.awt.Color(244, 243, 239));
        jPanel25.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jPanel26.setBackground(new java.awt.Color(230, 205, 141));
        jPanel26.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButton11.setBackground(new java.awt.Color(230, 205, 141));
        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jLabel31.setFont(new java.awt.Font("Roboto Thin", 1, 24)); // NOI18N
        jLabel31.setText("Administrar Pedidos Clientes");

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel31)
                .addGap(273, 273, 273))
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel26Layout.createSequentialGroup()
                        .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel26Layout.createSequentialGroup()
                        .addComponent(jLabel31)
                        .addGap(20, 20, 20))))
        );

        jPanel27.setBackground(new java.awt.Color(244, 243, 239));

        tablaPedClie.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tablaPedClie.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaPedClieMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tablaPedClie);

        jLabel3.setText("Codigo del Pedido:");

        jTextField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField3KeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 752, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addGap(180, 180, 180)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        rSButtonMetro3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/lista.png"))); // NOI18N
        rSButtonMetro3.setText("Generar nuevo Pedido");
        rSButtonMetro3.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro3.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro3.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro3.setColorTextHover(new java.awt.Color(0, 0, 0));
        rSButtonMetro3.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro3.setColorTextPressed(new java.awt.Color(0, 0, 0));
        rSButtonMetro3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro3ActionPerformed(evt);
            }
        });

        rSButtonMetro4.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/guardar_1.png"))); // NOI18N
        rSButtonMetro4.setText("Modificar Pedido");
        rSButtonMetro4.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro4.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro4.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro4.setColorTextHover(new java.awt.Color(0, 0, 0));
        rSButtonMetro4.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro4.setColorTextPressed(new java.awt.Color(0, 0, 0));
        rSButtonMetro4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro4ActionPerformed(evt);
            }
        });

        rSButtonMetro6.setBackground(new java.awt.Color(244, 243, 239));
        rSButtonMetro6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro6.setForeground(new java.awt.Color(0, 0, 0));
        rSButtonMetro6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/eliminar.png"))); // NOI18N
        rSButtonMetro6.setText("Eliminar");
        rSButtonMetro6.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro6.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro6.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro6.setColorTextHover(new java.awt.Color(0, 0, 0));
        rSButtonMetro6.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro6.setColorTextPressed(new java.awt.Color(0, 0, 0));
        rSButtonMetro6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(rSButtonMetro3, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(rSButtonMetro6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(rSButtonMetro4, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addComponent(jPanel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rSButtonMetro4, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rSButtonMetro3, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rSButtonMetro6, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(47, Short.MAX_VALUE))
        );

        PantallaClientes.getContentPane().add(jPanel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 490));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Gestion de Pedidos");
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(230, 205, 141));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Roboto Thin", 1, 36)); // NOI18N
        jLabel1.setText("Pedidos");

        jButton1.setBackground(new java.awt.Color(230, 205, 141));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/Atras.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(234, 234, 234)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(326, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 80));

        jPanel4.setBackground(new java.awt.Color(244, 243, 239));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel4.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 778, 20));

        jPanel13.setBackground(new java.awt.Color(244, 243, 239));
        jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Roboto Thin", 1, 14))); // NOI18N

        MPbotonMateriaPrima12.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/home.png"))); // NOI18N
        MPbotonMateriaPrima12.setText("Volver Al Home");
        MPbotonMateriaPrima12.setColorBorde(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        MPbotonMateriaPrima12.setColorHover(new java.awt.Color(230, 205, 141));
        MPbotonMateriaPrima12.setColorNormal(new java.awt.Color(244, 243, 239));
        MPbotonMateriaPrima12.setColorPressed(new java.awt.Color(244, 237, 210));
        MPbotonMateriaPrima12.setColorTextNormal(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima12.setColorTextPressed(new java.awt.Color(0, 0, 0));
        MPbotonMateriaPrima12.setDefaultCapable(false);
        MPbotonMateriaPrima12.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        MPbotonMateriaPrima12.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        MPbotonMateriaPrima12.setIconTextGap(25);
        MPbotonMateriaPrima12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MPbotonMateriaPrima12ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(274, 274, 274)
                .addComponent(MPbotonMateriaPrima12, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(282, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MPbotonMateriaPrima12, javax.swing.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE)
                .addGap(34, 34, 34))
        );

        jPanel4.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 770, 80));

        rSButtonMetro1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/usuario_1.png"))); // NOI18N
        rSButtonMetro1.setText("Administrar Pedidos Cliente");
        rSButtonMetro1.setColorBorde(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        rSButtonMetro1.setColorHover(new java.awt.Color(230, 205, 141));
        rSButtonMetro1.setColorNormal(new java.awt.Color(244, 243, 239));
        rSButtonMetro1.setColorPressed(new java.awt.Color(244, 237, 210));
        rSButtonMetro1.setColorTextHover(new java.awt.Color(0, 0, 0));
        rSButtonMetro1.setColorTextNormal(new java.awt.Color(0, 0, 0));
        rSButtonMetro1.setColorTextPressed(new java.awt.Color(0, 0, 0));
        rSButtonMetro1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro1ActionPerformed(evt);
            }
        });
        jPanel4.add(rSButtonMetro1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 70, 238, 56));

        botonPedidosProveedor.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonPedidosProveedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/camion.png"))); // NOI18N
        botonPedidosProveedor.setText("Pedidos Proveedor");
        botonPedidosProveedor.setColorBorde(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        botonPedidosProveedor.setColorHover(new java.awt.Color(230, 205, 141));
        botonPedidosProveedor.setColorNormal(new java.awt.Color(244, 243, 239));
        botonPedidosProveedor.setColorPressed(new java.awt.Color(244, 237, 210));
        botonPedidosProveedor.setColorTextHover(new java.awt.Color(0, 0, 0));
        botonPedidosProveedor.setColorTextNormal(new java.awt.Color(0, 0, 0));
        botonPedidosProveedor.setColorTextPressed(new java.awt.Color(0, 0, 0));
        botonPedidosProveedor.setDefaultCapable(false);
        botonPedidosProveedor.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        botonPedidosProveedor.setIconTextGap(10);
        botonPedidosProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonPedidosProveedorActionPerformed(evt);
            }
        });
        jPanel4.add(botonPedidosProveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 70, 240, 56));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 800, 420));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void botonPedidosProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonPedidosProveedorActionPerformed
        dispose();
        deshabilitartablapedprov();
        detallepedidoprov();
        pantallaProveedor.setVisible(true);
        this.setVisible(false);
        pantallaProveedor.setSize(817, 540);
        pantallaProveedor.setResizable(false);
        pantallaProveedor.setLocationRelativeTo(null);

        PantallaPedidos home = new PantallaPedidos();
        home.setVisible(false);


    }//GEN-LAST:event_botonPedidosProveedorActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        pantallaProveedor.setVisible(false);
        PantallaPedidos home = new PantallaPedidos();
        home.setVisible(true);
        this.setVisible(false);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        dispose();
        nuevoPedidoProveedor.setVisible(false);
        pantallaProveedor.setVisible(true);

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        dispose();
        modificarPedido.setVisible(false);
        pantallaProveedor.setVisible(true);


    }//GEN-LAST:event_jButton4ActionPerformed

    private void MPbotonMateriaPrima7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima7ActionPerformed

        int idmp = (int) jComboBox5.getSelectedIndex();
        int cant = (int) jSpinner3.getValue();
        int id = (int) jComboBox4.getSelectedIndex();
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
        //actualiza los datos del pedido proveedor 
        int respuesta = JOptionPane.showConfirmDialog(this, "¿ESTA SEGURO DE REALIZAR LOS CAMBIOS?", "CONFIRMACION CAMBIOS", JOptionPane.YES_NO_OPTION, HEIGHT);

        try {
            if (respuesta == JOptionPane.YES_OPTION) {
                con.ps = conn.prepareStatement("UPDATE detalle_pedido_proveedor SET id_materia_prima=? ,cantidad=?  WHERE id_pedido_proveedor=?");

                con.ps.setInt(1, idmp);//combobox
                con.ps.setInt(2, cant);//jspinner
                con.ps.setInt(3, id);//jspinner

                int res = con.ps.executeUpdate();
                if (res > 0) {
                    JOptionPane.showMessageDialog(null, "LOS DATOS HAN SIDO MODIFICADOS CORRECTAMENTE");
                    modificarpedprov();
                } else {
                    JOptionPane.showMessageDialog(null, "EL DATOS NO SE HA MODIFICADO CORRECTAMENTE");

                }
            } else if (respuesta == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(null, "SE HAN CANCELADO LOS CAMBIOS");
            }
        } catch (Exception e) {
            System.err.println(e);
        }
        con.closeConexion();

    }//GEN-LAST:event_MPbotonMateriaPrima7ActionPerformed

    private void MPbotonMateriaPrima8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima8ActionPerformed
        dispose();
        pantallaInicio home = new pantallaInicio();// TODO add your handling code here:
        home.setVisible(true);
        modificarPedido.setVisible(false);

    }//GEN-LAST:event_MPbotonMateriaPrima8ActionPerformed

    private void MPbotonMateriaPrima3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima3ActionPerformed

        pantallaProveedor.setVisible(false);
        nuevoPedidoProveedor.setVisible(true);
        nuevoPedidoProveedor.setSize(899, 590);
        nuevoPedidoProveedor.setResizable(false);
        nuevoPedidoProveedor.setLocationRelativeTo(null);

    }//GEN-LAST:event_MPbotonMateriaPrima3ActionPerformed

    private void MPbotonMateriaPrima4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima4ActionPerformed
deshabilitarmodificarpedprov();
        pantallaProveedor.setVisible(false);
        modificarPedido.setVisible(true);
        modificarPedido.setSize(818, 490);
        modificarPedido.setResizable(false);
        modificarPedido.setLocationRelativeTo(null);
    }//GEN-LAST:event_MPbotonMateriaPrima4ActionPerformed

    private void MPbotonMateriaPrima10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima10ActionPerformed
        NuevoPedClie.setVisible(false);

        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);
        this.setVisible(false);

        cargar("");
    }//GEN-LAST:event_MPbotonMateriaPrima10ActionPerformed

    private void rSButtonMetro1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro1ActionPerformed
cargarpedido("");
bloqueoopcionesdtr();
        dispose();
        PantallaClientes.setVisible(true);
        PantallaClientes.setSize(774, 490);
        PantallaClientes.setLocationRelativeTo(null);
        PantallaClientes.setResizable(false);
    }//GEN-LAST:event_rSButtonMetro1ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        PantallaClientes.setVisible(false);

        PantallaPedidos home = new PantallaPedidos();
        home.setVisible(true);
    }//GEN-LAST:event_jButton11ActionPerformed

    private void rSButtonMetro3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro3ActionPerformed
pedidocl("");
cargarcliente();

        PantallaClientes.setVisible(false);
        NuevoPedClie.setVisible(true);
        NuevoPedClie.setSize(916, 560);
        NuevoPedClie.setResizable(false);
        NuevoPedClie.setLocationRelativeTo(null);
    }//GEN-LAST:event_rSButtonMetro3ActionPerformed

    private void rSButtonMetro4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro4ActionPerformed
cargadescripciondtr();
        cargacodigodtr();
        PantallaClientes.setVisible(false);
        ModificarPedCLiente.setVisible(true);
        ModificarPedCLiente.setSize(699, 590);
        ModificarPedCLiente.setLocationRelativeTo(null);
        ModificarPedCLiente.setResizable(false);
    }//GEN-LAST:event_rSButtonMetro4ActionPerformed

    private void MPbotonMateriaPrima11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima11ActionPerformed
        ModificarPedCLiente.setVisible(false);
        PantallaClientes.setVisible(false);
        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);

        cargar("");
    }//GEN-LAST:event_MPbotonMateriaPrima11ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        NuevoPedClie.setVisible(false);
        PantallaClientes.setVisible(true);

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed

        ModificarPedCLiente.setVisible(false);
        PantallaClientes.setVisible(true);
    }//GEN-LAST:event_jButton9ActionPerformed

    private void MPbotonMateriaPrima6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima6ActionPerformed
        pantallaProveedor.setVisible(false);
        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);
    }//GEN-LAST:event_MPbotonMateriaPrima6ActionPerformed

    private void MPbotonMateriaPrima12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima12ActionPerformed
        dispose();
        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);


    }//GEN-LAST:event_MPbotonMateriaPrima12ActionPerformed

    private void modifrpedcliente2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifrpedcliente2ActionPerformed
        int respuesta = JOptionPane.showConfirmDialog(this, "¿ESTA SEGURO DE REALIZAR LOS CAMBIOS?", "CONFIRMACION CAMBIOS", JOptionPane.YES_NO_OPTION, HEIGHT);

        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();

        int fila = jTable6.getSelectedRow();
        int id = parseInt(jTable6.getValueAt(fila, 0).toString());

        try {
            if (respuesta == JOptionPane.YES_OPTION) {
                int valor = (int) jComboBox2.getSelectedIndex();
                int valor2 = (int) jSpinner1.getValue();

                c.ps = conn.prepareStatement("UPDATE detalle_pedido SET id_producto=?,cantidad=? where id_detalle_pedido=?");

                c.ps.setInt(1, valor);
                c.ps.setInt(2, valor2);
                c.ps.setInt(3, id);

                int res = c.ps.executeUpdate();

                if (res > 0) {
                    JOptionPane.showMessageDialog(null, "LOS DATOS HAN SIDO MODIFICADOS CORRECTAMENTE");
                    jComboBox2.setSelectedIndex(0);
                    jSpinner1.setValue(0);
                    jComboBox6.setSelectedIndex(0);
                    modificadtr();
                } else {
                    JOptionPane.showMessageDialog(null, "LOS DATOS NO SE HA MODIFICADO CORRECTAMENTE");

                }

            } else if (respuesta == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(null, "SE HAN CANCELADO LOS CAMBIOS");
            }

        } catch (Exception e) {
            System.err.println(e);

        }

        c.closeConexion();

    }//GEN-LAST:event_modifrpedcliente2ActionPerformed

    private void rSButtonMetro6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro6ActionPerformed

        int respuesta = JOptionPane.showConfirmDialog(this, "¿ESTA SEGURO QUE DESEA ELIMINAR?", "ELIMINAR ELEMENTO", JOptionPane.YES_NO_OPTION, HEIGHT);

        if (respuesta == JOptionPane.YES_OPTION) {

            Conectividad con = new Conectividad();
            Connection conn = con.getConexion();

            Date fecha = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fechaactual = sdf.format(fecha);

          int fila = tablaPedClie.getSelectedRow();

        int valor = parseInt(tablaPedClie.getValueAt(fila, 0).toString());

            con.getConexion();
            try {

                con.ps = conn.prepareStatement("UPDATE pedido_cliente SET statusbajapedcl=? WHERE id_pedido_cliente=" + valor);

                con.ps.setString(1, fechaactual);

                con.ps.executeUpdate();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "El pedido no se ha podido dar de baja");
            }
            try {

                con.ps = conn.prepareStatement("UPDATE detalle_pedido SET statusbajadt=? WHERE id_pedido_cliente=" + valor);

                con.ps.setString(1, fechaactual);

                int res = con.ps.executeUpdate();
                cargarpedido("");
                if (res > 0) {
                    JOptionPane.showMessageDialog(null, "pedido dado de baja");
                    cargarpedido("");
                    pedidocl("");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "El pedido no se ha podido dar de baja");
            }

            con.closeConexion();

        } else if (respuesta == JOptionPane.NO_OPTION) {
            JOptionPane.showMessageDialog(null, "SE HAN CANCELADO LOS CAMBIOS");
        }
    }//GEN-LAST:event_rSButtonMetro6ActionPerformed

    private void rSButtonMetro8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro8ActionPerformed
        // TODO add your handling code here:
        PantallaClientes cl = new PantallaClientes();
        cl.setVisible(true);

    }//GEN-LAST:event_rSButtonMetro8ActionPerformed

    private void MPbotonMateriaPrima9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MPbotonMateriaPrima9ActionPerformed
        // TODO add your handling code here:
        dispose();
        PantallaPedidos pd = new PantallaPedidos();
        pd.setVisible(false);

        pantallaInicio home = new pantallaInicio();
        home.setVisible(true);
    }//GEN-LAST:event_MPbotonMateriaPrima9ActionPerformed

    private void generarpedido1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generarpedido1ActionPerformed
        // TODO add your handling code here:
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
        con.getConexion();
        int idprov = (int) jComboBox14.getSelectedIndex();

        Date fecha = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fechaactual = sdf.format(fecha);
        try {

            con.ps = conn.prepareStatement("INSERT INTO pedido_a_proveedor(fecha,id_proveedor,control) VALUES (?,?,?)");

            con.ps.setString(1, fechaactual);
            con.ps.setInt(2, idprov);
            con.ps.setInt(3, 0);

            int res = con.ps.executeUpdate();

            if (res > 0) {
                JOptionPane.showMessageDialog(null, "DESCRIPCION PROVEEDOR  SE GUARDO CORRECTAMENTE.");
                cargarprovped();
                cargar("");
                resercombobox();
bloquearbtn();
            } else {
                JOptionPane.showMessageDialog(null, "DESCRIPCION DEL PEDIDO PROVEEDOR NO SE HA GUARDADO CORRECTAMENTE");
            }

        } catch (Exception e) {
            System.err.println(e);
        }

        con.getConexion();
    }//GEN-LAST:event_generarpedido1ActionPerformed

    private void generarpedido3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generarpedido3ActionPerformed
        // TODO add your handling code here:
      Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
         con.getConexion();
 if (jCheckBox3.isSelected() == false) {
            float cantidades = (float) jSpinField3.getValue();
            float engramos = cantidades / 1000;
        int fila = jTable1.getSelectedRow();
        int valor = parseInt(jTable1.getValueAt(fila, 0).toString());

        try {
           

            float cantidad = (float) jSpinner2.getValue();

            int selectmp = (int) jComboBox7.getSelectedIndex();

            con.ps = conn.prepareStatement("INSERT INTO detalle_pedido_proveedor(cantidad,id_materia_prima,id_pedido_proveedor) VALUES (?,?,?)");

            con.ps.setFloat(1, cantidad);
            con.ps.setInt(2, selectmp);
            con.ps.setInt(3, valor);

            int res = con.ps.executeUpdate();
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "DETALLE DEl PEDIDO PROVEEDOR  SE GUARDO CORRECTAMENTE.");
                resercombobox();
              bloquearbtn();
            }

        } catch (Exception e) {
            //System.err.println(e);
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "LOS DATOS DEL PEDIDO PROVEEDOR NO SE HA GUARDADO CORRECTAMENTE");

            con.closeConexion();

        }

 }
    }//GEN-LAST:event_generarpedido3ActionPerformed
void detallepedidoprov(){
     Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
        con.getConexion();

    
        String detalleProv[] = new String[3];
        String[] titulos4 = {"Ingrediente ", "Cantidad",};
        con.model = new DefaultTableModel(null, titulos4);
        try {

            String SQL = "SELECT DISTINCT nombre FROM `pedido_a_proveedor` AS pp JOIN detalle_pedido_proveedor dpp ON pp.id_pedido_proveedor=dpp.id_pedido_proveedor  JOIN proveedor prov on pp.id_proveedor=prov.id_proveedor where pp.statusbajapedprov is null and dpp.statusbajadtpedprov is null and control=0";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
 jComboBox11.addItem(rs.getString("nombre"));
        jComboBox5.addItem(rs.getString("descripcion"));       
            }
            
        
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
}
    private void jComboBox11ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox11ItemStateChanged
        // TODO add your handling code here:
       Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
  

        int Filtros = (int) jComboBox11.getSelectedIndex();

        String detalleProv[] = new String[3];
        String[] titulos4 = {"Ingrediente ","Cantidad","Unidad Medida"};
        c.model = new DefaultTableModel(null, titulos4);
       c.getConexion();      
        try {

          String SQL = "SELECT id_detalle_pedido_proveedor,descripcion,cantidad,unidad_medida FROM detalle_pedido_proveedor AS dpp JOIN materia_prima mp ON dpp.id_materia_prima=mp.id_materia_prima JOIN pedido_a_proveedor pap ON dpp.id_pedido_proveedor=pap.id_pedido_proveedor where statusbajadtpedprov is null and control=0";
         Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {

                detalleProv[0] = rs.getString("descripcion");
                detalleProv[1] = rs.getString("cantidad");
                detalleProv[2] = rs.getString("unidad_medida");

                c.model.addRow(detalleProv);
                jTable2.setModel(c.model);

             

            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }


    }//GEN-LAST:event_jComboBox11ItemStateChanged

    private void generarpedido1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_generarpedido1MouseClicked
        // TODO add your handling code here:

        cargar("");
        nuevoPedidoProveedor.setVisible(false);
        nuevoPedidoProveedor.setVisible(true);
        nuevoPedidoProveedor.setSize(890, 590);
        nuevoPedidoProveedor.setResizable(false);
        nuevoPedidoProveedor.setLocationRelativeTo(null);
    }//GEN-LAST:event_generarpedido1MouseClicked

    private void generarpedido3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_generarpedido3MouseClicked
        // TODO add your handling code here:
          
/*
        nuevoPedidoProveedor.setVisible(false);
        nuevoPedidoProveedor.setVisible(true);
        nuevoPedidoProveedor.setSize(890, 590);
        nuevoPedidoProveedor.setResizable(false);
        nuevoPedidoProveedor.setLocationRelativeTo(null);*/
    }//GEN-LAST:event_generarpedido3MouseClicked

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        habilitartablapedprov();
jTable3.setVisible(true);
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
        int fila = jTable1.getSelectedRow();

        int valor = parseInt(jTable1.getValueAt(fila, 0).toString());

        String[] titulos = {"cod detalle", "descripcion", "cantidad","unidad_medida"};
        con.model = new DefaultTableModel(null, titulos);
        String filtrar[] = new String[4];
        con.getConexion();

        try {

            String SQL = "select * from detalle_pedido_proveedor AS dpp join materia_prima mp ON dpp.id_materia_prima=mp.id_materia_prima where id_pedido_proveedor =" + valor;
            Statement stmt = conn.createStatement();
            con.rs = stmt.executeQuery(SQL);
            while (con.rs.next()) {
                bloqueopaneldtr();
                cargardetalleproveedor("");
                if (fila >= 0) {

                    filtrar[0] = con.rs.getString("id_detalle_pedido_proveedor");
                    filtrar[1] = con.rs.getString("descripcion");
                    filtrar[2] = con.rs.getString("cantidad");
                    filtrar[3] = con.rs.getString("unidad_medida");
                    con.model.addRow(filtrar);
                    jTable3.setModel(con.model);

                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1HierarchyChanged(java.awt.event.HierarchyEvent evt) {//GEN-FIRST:event_jTable1HierarchyChanged
        // TODO add your handling code here:

    }//GEN-LAST:event_jTable1HierarchyChanged

    private void rSButtonMetro7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro7ActionPerformed
        // TODO add your handling code here:
        int fila = jTable4.getSelectedRow();
        int valor1 = parseInt(jTable4.getValueAt(fila, 0).toString());
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
        if (jCheckBox3.isSelected() == true) {
            float cantidad = (float) jSpinField3.getValue();
            float engramos = cantidad / 1000;
            try {

                con.getConexion();

                int provp = (int) jComboBox8.getSelectedIndex();

                con.ps = conn.prepareStatement("INSERT INTO detalle_pedido(id_producto,cantidad,id_pedido_cliente) VALUES (?,?,?)");

                con.ps.setInt(1, provp);
                con.ps.setFloat(2, engramos);
                con.ps.setInt(3, valor1);

                int res = con.ps.executeUpdate();

                if (res > 0) {

                    JOptionPane.showMessageDialog(null, "DETALLE DE PEDIDO SE GENERO CORRECTAMENTE");

                } else {
                    JOptionPane.showMessageDialog(null, "EL DETALLE DE PEDIOD NO SE HA GENERADO  CORRECTAMENTE");

                }

            } catch (Exception e) {
                //System.err.println(e);
                e.printStackTrace();
            }
            con.closeConexion();

        } else {
            try {

                con.getConexion();
                int cantidad = (int) jSpinField3.getValue();

                int provp = (int) jComboBox8.getSelectedIndex();

                con.ps = conn.prepareStatement("INSERT INTO detalle_pedido(id_producto,cantidad,id_pedido_cliente) VALUES (?,?,?)");

                con.ps.setInt(1, provp);
                con.ps.setInt(2, cantidad);
                con.ps.setInt(3, valor1);

                int res = con.ps.executeUpdate();
                detallepdc("");
                cargarpedido("");
                if (res > 0) {

                    JOptionPane.showMessageDialog(null, "DETALLE DE PEDIDO SE GENERO CORRECTAMENTE");

                } else {
                    JOptionPane.showMessageDialog(null, "EL DETALLE DE PEDIOD NO SE HA GENERADO  CORRECTAMENTE");

                }

            } catch (Exception e) {
                //System.err.println(e);
                e.printStackTrace();
            }
            con.closeConexion();
        }

    }//GEN-LAST:event_rSButtonMetro7ActionPerformed

    private void jTable4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable4MouseClicked
        // TODO add your handling code here:+
        activarbtngenerarcl();
        activaropcionesdtr();
        bloqueopanelpdc();
    //    lecturaegramos();
        detallepdc("");
    }//GEN-LAST:event_jTable4MouseClicked

    private void rSButtonMetro2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro2ActionPerformed
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
        con.getConexion();
        try {

            Date fecha = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String fechaactual = sdf.format(fecha);

            int cliente = (int) jComboBox3.getSelectedIndex();

            String prod = (String) selectprod.getSelectedItem();

            con.ps = conn.prepareStatement("INSERT INTO pedido_cliente(fecha,estado,id_cliente) VALUES (?,?,?)");

            con.ps.setString(1, fechaactual);

            con.ps.setString(2, "Pendiente");
            con.ps.setInt(3, cliente);

            int res = con.ps.executeUpdate();
            cargarpedido("");
            pedidocl("");

            if (res > 0) {
 bloquearbtn();
                JOptionPane.showMessageDialog(null, "DATOS DEl PEDIDO SE AGREGO CORRECTAMENTE");

            } else {
                JOptionPane.showMessageDialog(null, "EL PEDIDO NO FUE AGREGADO CORRECTAMENTE");

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        con.closeConexion();
    }//GEN-LAST:event_rSButtonMetro2ActionPerformed

    private void jComboBox6ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox6ItemStateChanged
 modificadtr();

    }//GEN-LAST:event_jComboBox6ItemStateChanged

    private void jTable6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable6MouseClicked
        // TODO add your handling code here:
        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        int fila = jTable6.getSelectedRow();
        int valor1 = parseInt(jTable6.getValueAt(fila, 0).toString());

        c.getConexion();
        try {

            c.ps = conn.prepareStatement("SELECT * FROM detalle_pedido AS dp join producto p ON dp.id_producto=p.id_producto WHERE id_detalle_pedido=?");
            c.ps.setInt(1, valor1);

            c.rs = c.ps.executeQuery();

            if (c.rs.next()) {
                jComboBox2.setSelectedItem(c.rs.getString("descripcion"));
                jSpinner1.setValue(c.rs.getInt("cantidad"));

            } else {
                JOptionPane.showMessageDialog(null, "No existe un producto con ese nombre");
            }

        } catch (Exception e) {
            System.err.println(e);
            JOptionPane.showMessageDialog(null, "error");
        }
        c.closeConexion();
    }//GEN-LAST:event_jTable6MouseClicked

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        modificarpedprov();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jTable7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable7MouseClicked
        // TODO add your handling code here:
        habilitarmodificarpedprov();
        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        int fila = jTable7.getSelectedRow();
        int valor1 = parseInt(jTable7.getValueAt(fila, 0).toString());

        c.getConexion();
        try {

            c.ps = conn.prepareStatement("SELECT * FROM detalle_pedido_proveedor AS dpp join materia_prima mp ON dpp.id_materia_prima = mp.id_materia_prima WHERE  id_detalle_pedido_proveedor= ? ");
            c.ps.setInt(1, valor1);

            c.rs = c.ps.executeQuery();

            if (c.rs.next()) {
                jComboBox5.setSelectedItem(c.rs.getString("descripcion"));
                jSpinner3.setValue(c.rs.getInt("cantidad"));

            } else {
                JOptionPane.showMessageDialog(null, "error al seleccionar el ingrediente");
            }

        } catch (Exception e) {
            System.err.println(e);
            JOptionPane.showMessageDialog(null, "error");
        }
        c.closeConexion();
    }//GEN-LAST:event_jTable7MouseClicked

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jCheckBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jCheckBox1ItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ItemStateChanged

    private void jCheckBox1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCheckBox1MouseClicked
        // TODO add your handling code here:
        Conectividad con = new Conectividad();
        Connection conn = con.getConexion();

        int fila = jTable1.getSelectedRow();
        int check = parseInt(jTable1.getValueAt(fila, 0).toString());
        if (jCheckBox1.isSelected() == true) {
            try {

                con.getConexion();
                String SQL = "SELECT * from pedido_a_proveedor where id_pedido_proveedor= " + check;
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(SQL);
                while (rs.next()) {

                    try {

                        int cantidad = (int) jSpinner2.getValue();
                        int selectmp = (int) jComboBox7.getSelectedIndex();

                        con.ps = conn.prepareStatement("UPDATE materia_prima a, detalle_pedido_proveedor b SET a.stock = b.cantidad+a.stock WHERE a.id_materia_prima = b.id_materia_prima");

                        con.ps.executeUpdate();
                    } catch (Exception e) {
                        System.err.println(e);
                    }
                    try {
                        con.ps = conn.prepareStatement("UPDATE pedido_a_proveedor set control=1 where id_pedido_proveedor=" + check);
                        int res = con.ps.executeUpdate();
                        if (res > 0) {
                            JOptionPane.showMessageDialog(null, "SU VERIFICACION A SIDO REALIZADA.");
                            bloqueopaneldtr();
                            jComboBox7.setEnabled(false);
                            jSpinner2.setEnabled(false);
                            generarpedido3.setEnabled(false);
                            jCheckBox1.setEnabled(false);
                        }
                    } catch (Exception e) {

                    }

                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
            }
            con.closeConexion();
        }

    }//GEN-LAST:event_jCheckBox1MouseClicked

    private void jCheckBox2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCheckBox2MouseClicked
        // TODO add your handling code here:
        Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        int fila = jTable4.getSelectedRow();
        int filtrob = parseInt(jTable4.getValueAt(fila, 0).toString());
        if (jCheckBox2.isSelected() == true) {
            try {

                int cantidad = (int) jSpinner2.getValue();
                int selectmp = (int) jComboBox7.getSelectedIndex();

                c.ps = conn.prepareStatement("UPDATE pedido_cliente set estado=? where id_pedido_cliente=" + filtrob);
                c.ps.setString(1, "Entregado");

                int res = c.ps.executeUpdate();
                if (res > 0) {
                    JOptionPane.showMessageDialog(null, "El producto a sido entregado");
                    pedidocl("");

                } else {
                    JOptionPane.showMessageDialog(null, "Error no puedes marcar el producto como entregado");

                }
            } catch (Exception e) {
                System.err.println(e);
            }
        }
    }//GEN-LAST:event_jCheckBox2MouseClicked

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
         
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
       
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jCheckBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox3ActionPerformed

    private void jCheckBox3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jCheckBox3MouseClicked
        // TODO add your handling code here:

  
    }//GEN-LAST:event_jCheckBox3MouseClicked

    private void jComboBox7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox7MouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jComboBox7MouseClicked

    private void jComboBox7ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox7ItemStateChanged
        // TODO add your handling code here:
  
         Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
String dato = (String) jComboBox7.getSelectedItem();
        String mp[] = new String[8];
        String[] titulos2 = {""};
        con.model = new DefaultTableModel(null, titulos2);
        try {
            con.getConexion();
            String SQL = "SELECT  descripcion,unidad_medida FROM materia_prima where statusbajamp is null";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
             String umed= rs.getString("unidad_medida");
             String desc=rs.getString("descripcion");
                
             if(dato.equals(desc)){
                 
                 jTextField2.setText(umed);
                 break;
             }

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();

    }//GEN-LAST:event_jComboBox7ItemStateChanged

    private void jComboBox8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox8MouseClicked
        // TODO add your handling code here:
    

    }//GEN-LAST:event_jComboBox8MouseClicked

    private void jComboBox8ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox8ItemStateChanged
        // TODO add your handling code here:
            Conectividad con = new Conectividad();
        Connection conn = con.getConexion();
   int combos = (int) jComboBox8.getSelectedIndex();
        System.out.println(combos);

        try {
            con.getConexion();
            String SQL = "SELECT id_producto,unidad_medida from producto where statusbajaProd is null and id_producto="+combos;

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
       String umed = rs.getString("unidad_medida");
  
                   jTextField1.setText(umed);
           

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se ha podido conectar" + " " + e.getMessage());
        }
        con.closeConexion();
    }//GEN-LAST:event_jComboBox8ItemStateChanged

    private void jTable5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable5MouseClicked
        // TODO add your handling code here:
        bloqueoordprod();
        
    }//GEN-LAST:event_jTable5MouseClicked

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
         Conectividad c = new Conectividad();
        Connection conn = c.getConexion();
        int id=1;
        int valor=0;
        float valor1=0;
        int fila = jTable5.getSelectedRow();
        int filtrob = parseInt(jTable5.getValueAt(fila, 0).toString());
       
            c.getConexion();
                 //Traigo los datos seleccionados
            try{
                  c.ps = conn.prepareStatement("SELECT * FROM detalle_pedido  WHERE  id_detalle_pedido=?");
                   c.ps.setInt(1, filtrob);
                  c.rs = c.ps.executeQuery();
                   if (c.rs.next()){
                       valor=c.rs.getInt("id_producto");
                       valor1=c.rs.getFloat("cantidad");
                   
                       
                   }else{
                       System.out.println("no se encuentra el dato solicitado.");
                   }
            }catch(Exception e){
           
            }
           // System.out.println("traigo datos de: "+"producto: "+valor+" Cantidad: "+ valor1);
            
            //inserto los datos seleccionados en orden de produccion
            try{
                                  c.ps = conn.prepareStatement("INSERT INTO orden_de_produccion(id_producto,cantidad,interno) VALUES (?,?,?) ");
                                   c.ps.setInt(1, valor);
                                    c.ps.setFloat(2, valor1);
                                    c.ps.setFloat(3, 0);
                        
                                  c.ps.executeUpdate();
            }catch(Exception e){
                                 

            }
             //  System.out.println("inserto datos de: "+ " Producto: "+valor+" Cantidad: "+ valor1);
          
             //Verifico que id me agrego en el codigo de orden de produccion
            try{
                 c.ps = conn.prepareStatement("select max(id_orden_produccion)from orden_de_produccion");
                c.rs=c.ps.executeQuery();
                while(c.rs.next()){
                    id=c.rs.getInt(1);
                }
            }catch(Exception e){
                
            }
            //Actualizo la el id de orden de produccion desde detalle pedido
                try {

                int cantidad = (int) jSpinner2.getValue();
                int selectmp = (int) jComboBox7.getSelectedIndex();

                c.ps = conn.prepareStatement("UPDATE detalle_pedido set id_orden_produccion=? where id_detalle_pedido=" + filtrob);
                      c.ps.setInt(1, id);

                int res = c.ps.executeUpdate();
                
            } catch (Exception e) {
                System.err.println(e);
            }
                try {

                int cantidad = (int) jSpinner2.getValue();
                int selectmp = (int) jComboBox7.getSelectedIndex();

                c.ps = conn.prepareStatement("UPDATE pedido_cliente AS pc INNER JOIN detalle_pedido dp ON pc.id_pedido_cliente = dp.id_detalle_pedido SET pc.estado=? where dp.id_detalle_pedido=" + filtrob);
                      c.ps.setString(1,"En Produccion");

                int res = c.ps.executeUpdate();
                if (res > 0) {
                    JOptionPane.showMessageDialog(null, "La orden de produccion a sido generado");
                    pedidocl("");

                } else {
                    JOptionPane.showMessageDialog(null, "Error no puedes generar la orden de produccion");

                }
            } catch (Exception e) {
                System.err.println(e);
            }
                c.closeConexion();
        
    }//GEN-LAST:event_jButton7ActionPerformed

    private void tablaPedClieMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaPedClieMouseClicked
        // TODO add your handling code here:
        activarbotonelimienar();
    }//GEN-LAST:event_tablaPedClieMouseClicked

    private void jTextField3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField3KeyReleased
        // TODO add your handling code here:
        cargarpedido(""+jTextField3.getText());
        if(jTextField3.getText().isEmpty()){
             ocultartablapdc(); 
        }else{
             habilitartablapdc();  
        }
     
    }//GEN-LAST:event_jTextField3KeyReleased

    private void jComboBox6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox6MouseClicked
        // TODO add your handling code here:
       
    }//GEN-LAST:event_jComboBox6MouseClicked

    private void jComboBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox4ActionPerformed

    private void jComboBox11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox11MouseClicked
        // TODO add your handling code here:
         
    }//GEN-LAST:event_jComboBox11MouseClicked

    private void jComboBox14ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox14ItemStateChanged
        // TODO add your handling code here:
        activarbtngenerar();
    }//GEN-LAST:event_jComboBox14ItemStateChanged

    private void jComboBox3ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox3ItemStateChanged
        // TODO add your handling code here:
        activarbtngenerarcl();
    }//GEN-LAST:event_jComboBox3ItemStateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                try {
                    new PantallaPedidos().setVisible(true);

                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e.getMessage());

                }

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima10;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima11;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima12;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima3;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima4;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima6;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima7;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima8;
    private rsbuttom.RSButtonMetro MPbotonMateriaPrima9;
    private javax.swing.JFrame ModificarPedCLiente;
    private javax.swing.JFrame NuevoPedClie;
    private javax.swing.JFrame PantallaClientes;
    private rsbuttom.RSButtonMetro botonPedidosProveedor;
    private rsbuttom.RSButtonMetro generarpedido1;
    private rsbuttom.RSButtonMetro generarpedido3;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton9;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JComboBox<String> jComboBox11;
    private javax.swing.JComboBox<String> jComboBox14;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JComboBox<String> jComboBox6;
    private javax.swing.JComboBox<String> jComboBox7;
    private javax.swing.JComboBox<String> jComboBox8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator15;
    private javax.swing.JSeparator jSeparator19;
    private javax.swing.JSeparator jSeparator20;
    private javax.swing.JSeparator jSeparator23;
    private javax.swing.JSeparator jSeparator26;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private com.toedter.components.JSpinField jSpinField3;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JSpinner jSpinner2;
    private javax.swing.JSpinner jSpinner3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTable jTable6;
    private javax.swing.JTable jTable7;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JFrame modificarPedido;
    private rsbuttom.RSButtonMetro modifrpedcliente2;
    private javax.swing.JFrame nuevoPedidoProveedor;
    private javax.swing.JFrame pantallaProveedor;
    private rsbuttom.RSButtonMetro rSButtonMetro1;
    private rsbuttom.RSButtonMetro rSButtonMetro2;
    private rsbuttom.RSButtonMetro rSButtonMetro3;
    private rsbuttom.RSButtonMetro rSButtonMetro4;
    private rsbuttom.RSButtonMetro rSButtonMetro6;
    private rsbuttom.RSButtonMetro rSButtonMetro7;
    private rsbuttom.RSButtonMetro rSButtonMetro8;
    private javax.swing.JComboBox<String> selectprod;
    private javax.swing.JTable tablaPedClie;
    // End of variables declaration//GEN-END:variables
}
